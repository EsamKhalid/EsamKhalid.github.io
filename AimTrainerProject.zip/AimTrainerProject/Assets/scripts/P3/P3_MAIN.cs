using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class P3_MAIN : MonoBehaviour
{
	[SerializeField] private Button gridshotButton;
	[SerializeField] private Button linePathButton;


	private void Start()
	{
		gridshotButton.onClick.AddListener(delegate { goToGridshot(); });
		linePathButton.onClick.AddListener(delegate { goToLinePath(); });
	}
	public void goToGridshot()
	{
		SceneManager.LoadScene(sceneBuildIndex: 1);
	}
	public void goToLinePath()
	{
		SceneManager.LoadScene(sceneBuildIndex: 2);
	}
}