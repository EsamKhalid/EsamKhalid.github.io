using System.Collections.Generic;
using UnityEngine;

public class P3_LP : MonoBehaviour
{

	private float minx;
	private float maxx;
	private float miny;
	private float maxy;
	private float minz;
	private float maxz;

	private Vector3 SpawnPosition;

	[SerializeField] private GameObject corner1;
	[SerializeField] private GameObject corner2;
	[SerializeField] private GameObject corner3;
	[SerializeField] private GameObject corner4;

	private float hoverTime;
	private float totalTime;
	private float percentage;

	private GameObject[] targetArray;
	private GameObject[] targetLines;
	private Vector3[] targetPoints;

	[SerializeField] private P3_OPT optionsClass;

	[SerializeField] private GameObject graphBackground;
	[SerializeField] private Canvas resultsPage;

	private float damage = 10f;
	private float range = 100f;

	[SerializeField] private GameObject gun;
	[SerializeField] private GameObject playerCharacter;
	[SerializeField] private Camera playerCamera;
	[SerializeField] private LayerMask Player;



	//STATS 
	private Vector3 shotPosition;
	private float errorSize;

	private float shotsTotal;
	private float targetsHit;

	private float accuracy;

	private float totalScore;

	private float targetsHitInSecond;

	public static float totalReactionTime;
	//STATS 


	//TIME
	private float time;
	private float timer;

	private int secondsPassed;
	private int taskTime = 30;

	private bool taskEnded = false;
	private bool paused;

	private bool preGame = true;
	private bool pregametimerbool;
	private float pregametimer = 0;
	//TIME

	//GRAPH
	[SerializeField] private Camera graphCamera;
	[SerializeField] private Canvas graphCanvas;
	private List<Vector2> graphPoints = new List<Vector2>();
	//GRAPH

	//Gridshot vars
	private int TotalTargetsSpawned = 0; //Used to be TotalTargets
	private int MaxTargetsSpawned = 1; //Used to be TargetCount
	private Vector3 startspawn;
	//End Gridshot vars

	private void Start()
	{
		maxy = corner1.transform.position.y;
		miny = corner3.transform.position.y;
		maxx = corner2.transform.position.x;
		minx = corner1.transform.position.x;

		targetArray = new GameObject[MaxTargetsSpawned + 1];
		targetLines = new GameObject[targetArray.Length - 1];
		targetPoints = new Vector3[MaxTargetsSpawned + 1];

	}
	void Update()
	{
		while (TotalTargetsSpawned < MaxTargetsSpawned)
		{
			spawnTargets();
		}

		paused = optionsClass.get_paused();
		preGame = optionsClass.get_preGame();

		//counts down the timers only when the game isnt paused and not in pregame state
		if (!paused && !preGame)
		{
			time += Time.deltaTime;
			timer += Time.deltaTime;
		}

		//if the player's y position reaches a certain value
		if (playerCharacter.transform.position.y <= -20)
		{
			//resets the player's position
			playerCharacter.transform.position = new Vector3(-111f, 2f, -19f);

		}


		//when the fire button is clicked it calls the shoot() function
		if (Input.GetButtonDown("Fire1"))
		{
			if(!preGame && !taskEnded && !preGame) 
			{
				shoot();
			}
			
		}

		if (time > 1)
		{
			//generateHoverTimeGraphPositions();
			secondsPassed += 1;
			time = 0;
		}

		if (secondsPassed >= taskTime && !taskEnded)
		{
			endTask();
		}
	}

	private void spawnTargets()
	{
		//Generates random values for x and y spawn coordinates
		float randy = Random.Range(miny, maxy);
		float randx = Random.Range(minx, maxx);
		//applies the randomly generated numbers to the spawnpositon vector to use to spawn the targets
		SpawnPosition.y = randy;
		SpawnPosition.x = randx;
		SpawnPosition.z = corner1.transform.position.z;

		//Creates a sphere and adds to targetArray
		targetArray[TotalTargetsSpawned] = GameObject.CreatePrimitive(PrimitiveType.Sphere);
		//Changes the position of the spawned target to the spawnposition generated above
		targetArray[TotalTargetsSpawned].transform.position = SpawnPosition;
		//Changes the scale to size it by 1.5x
		targetArray[TotalTargetsSpawned].transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);

		targetArray[TotalTargetsSpawned].AddComponent<P3_TARGET>();

		targetPoints[1] = SpawnPosition;

		TotalTargetsSpawned += 1;

		if (targetsHit > 0)
		{
			generateLines();
		}
	}

	private void generateLines()
	{
		for (int i = 0; i < targetArray.Length - 1; i++)
		{
			//Creates a primitive cube object
			targetLines[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
			//Adds the "Colourchanger" script onto the created object
			targetLines[i].AddComponent<Colourchanger>();
			//Sets the position of the cube to be in between the position of the current and next index in the array
			targetLines[i].transform.position = (targetPoints[i] + targetPoints[i + 1]) / 2;
			//Changes the length to be the equal to the distance between the 2 points
			targetLines[i].transform.localScale = new Vector3(0.3f, Vector2.Distance(targetPoints[i], targetPoints[i + 1]), 0.3f);
			//Changes the rotation from the default rotation to rotate towards the position of the next point in the array
			targetLines[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, targetPoints[i + 1] - targetPoints[i]);
		}
	}
	private void generateHoverTimeGraphPositions()
	{
		//YOU CAN GET RID OF THE TARGETS HIT >=1 AND ACT LIKE ITS A BUG THAT YOU FOUND AND FIXED
		if (targetsHit >= 1)
		{
			float tempPercent = (hoverTime / totalTime) * 100;
			percentage += (hoverTime / totalTime) * 100;
			Debug.Log(tempPercent);
			graphPoints.Add(new Vector2(0, tempPercent));
		}
	}
	private void endTask()
	{
		taskEnded = true;
		resultsPage.gameObject.SetActive(true);
		playerCamera.gameObject.SetActive(false);
		graphCamera.gameObject.SetActive(true);
		totalReactionTime = (taskTime / targetsHit) * 1000;
		targetsHit -= 2;
		errorSize /= targetsHit;
		hoverTime *= 100;
		calculateScore();
		Cursor.lockState = CursorLockMode.None;
		Cursor.visible = true;
		Debug.Log("accuracy is " + hoverTime);
		Debug.Log("erroreSize is " + errorSize);
		Debug.Log("shotsTotal is " + shotsTotal);
		Debug.Log("targetHit is" + targetsHit);
		Debug.Log("reactionTime is" + totalReactionTime);
		Debug.Log("totalScore is " + totalScore);
	}
	private void shoot()
	{
		//increments shots total by 1 for stats
		shotsTotal += 1;
		RaycastHit shotHit;

		//Returns true if the raycast hits an object
		if (Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward, out shotHit, range, ~Player))
		{
			//Checks the GameObject that has been hit to see if it has a "Target" Script on it and gets that instance of the class
			P3_TARGET target = shotHit.transform.GetComponent<P3_TARGET>();

			//If the GameObject does have a target script on it, cause the target to take damage
			if (target != null)
			{
				//tells the target to take damage using the public method in the class
				target.takedamage(damage);
				shotPosition = shotHit.point;
				errorSize += Vector2.Distance(shotHit.transform.position, shotPosition);

				if (targetsHit > 0)
				{
					hoverTime = targetLines[0].GetComponent<Colourchanger>().get_hoverTime();
					totalTime = targetLines[0].GetComponent<Colourchanger>().get_totalTime();
				}

				generateHoverTimeGraphPositions();

				GameObject.Destroy(targetLines[0]);

				targetPoints[0] = shotPosition;

				//increments targetshit by 1 for stats
				targetsHit += 1;
				//decrements totaltargetsspawned by 1 to allow for another target to be spawned
				TotalTargetsSpawned -= 1;
			}
		}
	}

	private void calculateScore()
	{
		float hoverTimeNormalised = (hoverTime - 0) / (100 - 0);
		float targetsHitNormalised = (targetsHit - 126) / (600 - 126);
		float errorSizeNormalised = (errorSize - 0) / (2.25f - 0);
		totalScore = ((hoverTimeNormalised * 2) + targetsHitNormalised + errorSizeNormalised) * 25000;
		Debug.Log(hoverTime);
		Debug.Log(hoverTimeNormalised);
	}
	//SETTERS
	public void set_paused(bool state)
	{
		paused = state;
	}
	//SETTERS

	//GETTERS
	public bool get_paused()
	{
		return paused;
	}
	public bool get_preGame()
	{
		return preGame;
	}
	public bool get_taskEnded()
	{
		return taskEnded;
	}
	public List<Vector2> get_graphPoints()
	{
		return graphPoints;
	}
	public float get_Timer()
	{
		return timer;
	}
	public int get_TaskTime()
	{
		return taskTime;
	}

	public float get_hoverTime()
	{
		return hoverTime;
	}

	public float get_errorSize()
	{
		return errorSize;
	}
	public float get_reactionTime()
	{
		return totalReactionTime;
	}

	public float get_shotsTotal()
	{
		return shotsTotal;
	}
	public float get_targetsHit()
	{
		return targetsHit;
	}
	public float get_avgPercent()	
	{
		return percentage / targetsHit;
	}

	public float get_score()
	{
		return totalScore;
	}
	//GETTERS
}

