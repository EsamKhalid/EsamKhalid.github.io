using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class P3_OPT : MonoBehaviour
{
	[SerializeField] private P3_GSCONTROLLER gridshotClass;
	[SerializeField] private P3_LP linePathClass;

	[SerializeField] private P3_MOUSE mouseClass;
	[SerializeField] private P3_UI UIclass;
		
	[SerializeField] private GameObject optionsMenu;
	[SerializeField] private GameObject mainSettings;
	[SerializeField] private GameObject controlsMenu;
	[SerializeField] private GameObject crosshairMenu;
	[SerializeField] private GameObject gameSensitivityMenu;
	[SerializeField] private GameObject preGameCanvas;
	[SerializeField] private Canvas gameUI;
	[SerializeField] private TextMeshProUGUI timerText;

	[SerializeField] private Button controlsButton;
	[SerializeField] private Button crosshairButton;
	[SerializeField] private Button gameSensButton;

	[SerializeField] private Button controlsToMainButton;
	[SerializeField] private Button crosshairToMainButton;
	[SerializeField] private Button gameSensToMainButton;


	[SerializeField] TextMeshProUGUI FOVValueText;
	[SerializeField] TextMeshProUGUI ADSValueText;
	[SerializeField] TextMeshProUGUI gameSensValueText;

	[SerializeField] private Slider fovSlider;
	[SerializeField] private Slider sensSlider;
	[SerializeField] private Slider ADSslider;

	[SerializeField] private Slider dotSizeSlider;
	[SerializeField] private Slider centerGapSlider;
	[SerializeField] private Slider lineWidthSlider;
	[SerializeField] private Slider lineHeightSlider;

	[SerializeField] private TMP_InputField fovInputField;
	[SerializeField] private TMP_InputField sensInputField;
	[SerializeField] private TMP_InputField ADSInputFeild;
	[SerializeField] private TMP_InputField FPSinputField;

	[SerializeField] private TMP_InputField dotSizeInputField;
	[SerializeField] private TMP_InputField centerGapInputField;
	[SerializeField] private TMP_InputField lineWidthInputField;
	[SerializeField] private TMP_InputField lineHeightInputField;

	[SerializeField] private TextMeshProUGUI preGameTimerText;
	[SerializeField] private Slider gameSensSlider;

	[SerializeField] private Button saveControlsButton;
	[SerializeField] private Button saveCrosshairButton;
	[SerializeField] private Button saveGamesensButton;

	[SerializeField] private Button restartTaskButton;
	
	//Game sensitivity
	[SerializeField] private TMP_Dropdown gameProfileDropDown;
	[SerializeField] private TMP_InputField gameSensInputField;
	private float[] gameMultipliers;
	private float[] minValueArray;
	private float[] maxValueArray;
	private int gameProfileIndex;
	//Game sensitivity


	private bool paused;
	private bool preGame = true;
	private bool preGameTimerBool;
	private float preGameTimer = 3;

	private bool taskEnded;

	private int FPS;

	private void Start()
	{
		getSettings();

		optionsMenu.SetActive(false);
		gameUI.gameObject.SetActive(false);
		preGameTimerText.text = preGameTimer.ToString("F2");

		gameMultipliers = new float[6];
		minValueArray = new float[6];
		maxValueArray = new float[6];

		gameMultipliers[0] = 1;
		gameMultipliers[1] = 79.617f;
		gameMultipliers[2] = 25.025f;
		gameMultipliers[3] = 25.025f;
		gameMultipliers[4] = 7.506f;
		gameMultipliers[5] = 6.517f;

		minValueArray[0] = 10f;
		minValueArray[1] = 0.01f;
		minValueArray[2] = 0.8f;
		minValueArray[3] = 0.05f;
		minValueArray[4] = 1f;
		minValueArray[5] = 1f;

		maxValueArray[0] = 1000f;
		maxValueArray[1] = 10f;
		maxValueArray[2] = 20f;
		maxValueArray[3] = 8;
		maxValueArray[4] = 200f;
		maxValueArray[5] = 100f;

		gameProfileDropDown.value = gameProfileIndex;
		gameSensSlider.maxValue = maxValueArray[gameProfileIndex];
		gameSensSlider.minValue = minValueArray[gameProfileIndex];
		fovSlider.value = mouseClass.get_fov();
		ADSslider.value = mouseClass.get_ADS();
		centerGapSlider.value = UIclass.get_centerGap();
		dotSizeSlider.value = UIclass.get_dotSize();
		lineWidthSlider.value = UIclass.get_lineWidth();
		lineHeightSlider.value = UIclass.get_lineHeight();

		//BUTTONCLICK LISTENERS
		//every time the buttons are clicked          //these methods are run
		controlsButton.onClick.AddListener(delegate { goToControlsFromMain(); });
		crosshairButton.onClick.AddListener(delegate { goToCrosshairFromMain(); });
		gameSensButton.onClick.AddListener(delegate { goToGameSensFromMain(); });

		controlsToMainButton.onClick.AddListener(delegate { goToMainFromControls(); });
		crosshairToMainButton.onClick.AddListener(delegate { goToMainFromCrosshair(); });
		gameSensToMainButton.onClick.AddListener(delegate { goToMainFromGameSens(); });

		saveControlsButton.onClick.AddListener(delegate { saveControlSettings(); });
		saveCrosshairButton.onClick.AddListener(delegate { saveCrosshairSettings(); });
		saveGamesensButton.onClick.AddListener(delegate { saveGameSens(); });

		restartTaskButton.onClick.AddListener(delegate { UIclass.restartTask(); });
		//BUTTONCLICK LISTENERS

		//SLIDER LISTENERS	
		//when the values of the sliders change, it runs the setters to set the value, with the paramater passed through being the value of the slider
		fovSlider.onValueChanged.AddListener(delegate { mouseClass.set_FOV(value: fovSlider.value); });
		sensSlider.onValueChanged.AddListener(delegate { mouseClass.set_Sens(value: sensSlider.value); });
		ADSslider.onValueChanged.AddListener(delegate { mouseClass.set_ADS(value: ADSslider.value); });

		dotSizeSlider.onValueChanged.AddListener(delegate { UIclass.set_dotSize(value: dotSizeSlider.value); });
		centerGapSlider.onValueChanged.AddListener(delegate { UIclass.set_centerGap(value: centerGapSlider.value); });
		lineWidthSlider.onValueChanged.AddListener(delegate { UIclass.set_lineWidth(value: lineWidthSlider.value); });
		lineHeightSlider.onValueChanged.AddListener(delegate { UIclass.set_lineHeight(value: lineHeightSlider.value); });

		gameSensSlider.onValueChanged.AddListener(delegate { gameSensSliderMethod(gameSensSlider.value); });
		//SLIDER LISTENERS

		//INPUTFIELD LISTENERS
		//when the user submits the inputfield it runs the input methods with the paramater passed through being the text in the inputfield
		fovInputField.onSubmit.AddListener(delegate { FOVInput(value: fovInputField.text); });
		sensInputField.onSubmit.AddListener(delegate { SensInput(value: sensInputField.text); });
		ADSInputFeild.onSubmit.AddListener(delegate { ADSInput(value: ADSInputFeild.text); });

		dotSizeInputField.onSubmit.AddListener(delegate { dotSizeInput(value: dotSizeInputField.text); });
		centerGapInputField.onSubmit.AddListener(delegate { centerGapInput(value: centerGapInputField.text); });
		lineWidthInputField.onSubmit.AddListener(delegate { lineWidthInput(value: lineWidthInputField.text); });
		lineHeightInputField.onSubmit.AddListener(delegate { lineHeightInput(value: lineHeightInputField.text); });

		FPSinputField.onSubmit.AddListener(delegate { FPSInput(value: FPSinputField.text); });

		gameSensInputField.onSubmit.AddListener(delegate { gameSensInput(gameSensInputField.text); });
		//INPUTFIELD LISTENERS

		//DROPDOWN LISTENERS
		gameProfileDropDown.onValueChanged.AddListener(delegate { selectGameProfile(gameProfileDropDown.value); });
		//DROPDOWN LISTENERS
	}
	private void Update()
	{

		if(SceneManager.GetActiveScene().buildIndex == 1)
		{
			gridshotClass.set_preGame(preGame);
		}
		else if(SceneManager.GetActiveScene().buildIndex == 2)
		{
			linePathClass.get_preGame();
		}

		//updates the text onscreen to the value its based on every frame
		gameSensValueText.text = (mouseClass.get_sens() / gameMultipliers[gameProfileIndex]).ToString();
		FOVValueText.text = mouseClass.get_fov().ToString();
		ADSValueText.text = mouseClass.get_ADS().ToString();

		gameSensSlider.value = (mouseClass.get_sens() / gameMultipliers[gameProfileIndex]);

		
		

		if (SceneManager.GetActiveScene().buildIndex == 1)
		{
			taskEnded = gridshotClass.get_taskEnded();
		}
		else if(SceneManager.GetActiveScene().buildIndex == 2)
		{
			taskEnded = linePathClass.get_taskEnded();
		}

		if (taskEnded)
		{
			//if the task has ended, it makes the gameUI invisible
			gameUI.gameObject.SetActive(false);
			paused = false;
		}

		if (Input.GetKeyDown(KeyCode.Escape))
		{
			//shows the settings page when escape is clicked
			mainSettings.SetActive(true);
		}

		if (paused)
		{
			//activates the optionsMenu if the game is paused
			optionsMenu.SetActive(true);
			preGameCanvas.gameObject.SetActive(false);
		}
		else if(!paused && !taskEnded)
		{
			optionsMenu.SetActive(false);
			controlsMenu.SetActive(false);
			crosshairMenu.SetActive(false);
			gameSensitivityMenu.SetActive(false);

			gameUI.gameObject.SetActive(true);
			timerText.gameObject.SetActive(true);
		}

		//When escape is pressed, it performs the NOT operation on paused
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			if (!taskEnded)
			{
				paused = !paused;
			}
		}

		//performs the actions when the game is in pregame state and the player isnt in the options menu
		if (preGame && !paused)
		{
			preGameCanvas.gameObject.SetActive(true);
			gameUI.gameObject.SetActive(false);
			if (Input.GetMouseButtonDown(0))
			{
				preGameTimerBool = true;
			}

			//starts the pregametimer countdown when true
			if (preGameTimerBool)
			{
				preGameTimer -= Time.deltaTime;
				preGameTimerText.text = preGameTimer.ToString();
			}

			//when the pregametimer reaches 0 or below
			if (preGameTimer <= 0)
			{
				//sets pregame to false to start the game
				preGame = false;
				gameUI.gameObject.SetActive(true);
				preGameCanvas.SetActive(false);
			}
		}
	}
	//these methods run when the input field is submitted
	public void FOVInput(string value)//takes in a string parameter
	{
		//if there is only integers in the string passed through, pass it into the temp value
		if (int.TryParse(value, out int tempval))
		{
			//if the tryparse returns true, use the setFOV method on the temp value
			mouseClass.set_FOV(tempval);
		}
	}
	public void SensInput(string value)
	{
		if (float.TryParse(value, out float tempval))
		{
			mouseClass.set_Sens(tempval);
		}
	}
	public void ADSInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			mouseClass.set_ADS(tempval);
		}
	}
	public void centerGapInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			UIclass.set_centerGap(tempval);
		}
	}
	public void dotSizeInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			UIclass.set_dotSize(tempval);
		}
	}
	public void lineWidthInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			UIclass.set_lineWidth(tempval);
		}
	}
	public void lineHeightInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			UIclass.set_lineHeight(tempval);
		}
	}

	public void FPSInput(string value)
	{
		if(int.TryParse(value, out int tempVal))
		{
			FPS = tempVal;
			Application.targetFrameRate = tempVal;
		}
	}


	//GAME SENSITIVITY///////////////////
	//this method is run when the dropdown menu is used
	public void selectGameProfile(int value)
	{
		//sets the min and max values of the slider to the value index of the arrays
		gameSensSlider.maxValue = maxValueArray[value];
		gameSensSlider.minValue = minValueArray[value];
		//if the default profile is selected, the slider increments in whole numbers
		if(value == 0)
		{
			gameSensSlider.wholeNumbers = true;
		}
		//the slider increments in non whole numbers
		else
		{
			gameSensSlider.wholeNumbers = false;
		}
		//sets the value of gameProfileIndex to the one that is selected using the dropDown menu
		gameProfileIndex = value;

	}

	public void gameSensSliderMethod(float value)
	{
		//sets the sensitivity to the value that is input using the slider multiplied by the game profile multiplier that is selected
		mouseClass.set_Sens(value * gameMultipliers[gameProfileIndex]);	
	}

	public void gameSensInput(string value)
	{
		if(float.TryParse(value, out float tempval))
		{
			//sets the sensitivity to the value that is input using the slider multiplied by the game profile multiplier that is selected
			mouseClass.set_Sens(tempval * gameMultipliers[gameProfileIndex]);
		}
	}
	//GAME SENSITIVITY///////////////////


	//SAVING
	private void saveControlSettings()
	{
		//uses playerprefs to set all of the floats in the registry
		PlayerPrefs.SetFloat("FOV", mouseClass.get_fov());
		PlayerPrefs.SetFloat("ADSmultiplier", mouseClass.get_ADS());
		PlayerPrefs.SetInt("FPS", FPS);
	}

	private void saveCrosshairSettings()
	{
		PlayerPrefs.SetFloat("dotSize", UIclass.get_dotSize());
		PlayerPrefs.SetFloat("centerGap", UIclass.get_centerGap());
		PlayerPrefs.SetFloat("lineWidth", UIclass.get_lineWidth());
		PlayerPrefs.SetFloat("lineHeight", UIclass.get_lineHeight());
	}
	private void saveGameSens()
	{
		PlayerPrefs.SetInt("gameProfileIndex", gameProfileIndex);
		PlayerPrefs.SetFloat("sens", mouseClass.get_sens());
	}

	private void getSettings()
	{
		//first makes sure that the values are actually saved
		if (PlayerPrefs.HasKey("FOV"))
		{
			//then retrieves the values using the setters
			mouseClass.set_FOV(PlayerPrefs.GetFloat("FOV"));
		}
		if (PlayerPrefs.HasKey("ADSmultiplier"))
		{
			mouseClass.set_ADS(PlayerPrefs.GetFloat("ADSmultiplier"));
		}
		if (PlayerPrefs.HasKey("FPS"))
		{
			Application.targetFrameRate = PlayerPrefs.GetInt("FPS");
			FPS = PlayerPrefs.GetInt("FPS");
		}
		if (PlayerPrefs.HasKey("dotSize"))
		{
			UIclass.set_dotSize(PlayerPrefs.GetFloat("dotSize"));
		}
		if (PlayerPrefs.HasKey("centerGap"))
		{
			UIclass.set_centerGap(PlayerPrefs.GetFloat("centerGap"));
		}
		if (PlayerPrefs.HasKey("lineWidth"))
		{
			UIclass.set_lineWidth(PlayerPrefs.GetFloat("lineWidth"));
		}
		if (PlayerPrefs.HasKey("lineHeight"))
		{
			UIclass.set_lineHeight(PlayerPrefs.GetFloat("lineHeight"));
		}
		if (PlayerPrefs.HasKey("gameProfileIndex"))
		{
			gameProfileIndex = PlayerPrefs.GetInt("gameProfileIndex");
		}
		if (PlayerPrefs.HasKey("sens"))
		{
			mouseClass.set_Sens(PlayerPrefs.GetFloat("sens"));
		}
	}
	//SAVING


	//GO TO MAIN
	//These methods run when the buttons are clicked and they control which options screens to show
	private void goToMainFromControls()
	{
		controlsMenu.SetActive(false);
		mainSettings.SetActive(true);
	}

	private void goToMainFromCrosshair()
	{
		crosshairMenu.SetActive(false);
		mainSettings.SetActive(true);
		gameUI.gameObject.SetActive(false);
		timerText.gameObject.SetActive(true);
	}
	private void goToMainFromGameSens()
	{
		gameSensitivityMenu.SetActive(false);
		mainSettings.SetActive(true);
	}
	//GO TO MAIN

	//GO TO SUBSETTINGS
	private void goToControlsFromMain()
	{
		mainSettings.SetActive(false);	
		controlsMenu.SetActive(true);
	}


	private void goToCrosshairFromMain()
	{
		mainSettings.SetActive(false);
		crosshairMenu.SetActive(true);
		gameUI.gameObject.SetActive(true);
		timerText.gameObject.SetActive(false);
	}
	private void goToGameSensFromMain()
	{
		mainSettings.SetActive(false);
		gameSensitivityMenu.SetActive(true);
	}
	//GO TO SUBSETTINGS


	//GETTERS
	public bool get_paused()
	{
		return paused;
	}
	public bool get_preGame()
	{
		return preGame;
	}
	//GETTERS


}

