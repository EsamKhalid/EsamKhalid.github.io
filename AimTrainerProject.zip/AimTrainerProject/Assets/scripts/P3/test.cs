using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
		
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Backspace))
        {
            PlayerPrefs.DeleteKey("FOV");
            PlayerPrefs.DeleteKey("ADSmultiplier");
            PlayerPrefs.DeleteKey("FPS");
            PlayerPrefs.DeleteKey("dotSize");
            PlayerPrefs.DeleteKey("centerGap");
            PlayerPrefs.DeleteKey("lineWidth");
            PlayerPrefs.DeleteKey("lineHeight");
            PlayerPrefs.DeleteKey("gameProfileIndex");
            PlayerPrefs.DeleteKey("sens");
            PlayerPrefs.DeleteKey("prevAcc");
            PlayerPrefs.DeleteKey("prevTHg");
            PlayerPrefs.DeleteKey("prevESg");
            PlayerPrefs.DeleteKey("prevRTg");
            PlayerPrefs.DeleteKey("prevSCg");
            PlayerPrefs.DeleteKey("prevTHl");
            PlayerPrefs.DeleteKey("prevESl");
            PlayerPrefs.DeleteKey("prevRTl");
            PlayerPrefs.DeleteKey("prevSCl");
            PlayerPrefs.DeleteKey("prevHT");
        }
    }
}
