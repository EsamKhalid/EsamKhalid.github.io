using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
public class P3_HOVER : MonoBehaviour
{
	private Scene currentScene;

	[SerializeField] private P3_GSCONTROLLER gridshotClass;
	[SerializeField] private P3_LP linePathClass;

	//This script was adapted from a code monkey tutorial on making tooltips
	//https://www.youtube.com/watch?v=YUIohCXt_pc

	[SerializeField] private RectTransform canvasRect;
	private TextMeshProUGUI valueText;
	private RectTransform backgroundRect;	
	private RectTransform rect;
	private string timeValue;

	//We can get this value based on the build index of the scene that we are currently in
	//E.g if the build index == index(gridshot 3x3) then we can set this value to be 30


	[SerializeField] private Camera graphCamera;
	private bool hittingPoint;

	private void Update()
	{

		//Sets the position of the value to be on the mouse position (divided by scale of canvas to make sure it stays constant even through resoluion change)
		Vector2 anchoredPosition = Input.mousePosition / canvasRect.localScale.x;

		//Makes sure the tooltip doesnt go off the screen
		if (anchoredPosition.x + backgroundRect.rect.width > canvasRect.rect.width)
		{

			anchoredPosition.x = canvasRect.rect.width - backgroundRect.rect.width;
		}

		if (anchoredPosition.y + backgroundRect.rect.height > canvasRect.rect.height)
		{

			anchoredPosition.y = canvasRect.rect.height - backgroundRect.rect.height;
		}

		rect.anchoredPosition = anchoredPosition;

		RaycastHit hit;
		//Shoots out a raycast from the mouse position from the graph camera
		Ray ray = graphCamera.ScreenPointToRay(Input.mousePosition);

		//returns true if the raycast is hitting an object and the object has the "graphPointHover" script
		//The only objects that contain that script are the graph points generated in the script "Gridhsot.cs"
		if (Physics.Raycast(ray, out hit) && hit.transform.GetComponent<graphPointHoverAccuracy>())
		{
			//Sets the A(accuracy) to the Y value since the Y value of the point is the accuracy
			//Sets the T(Time) to the X position since the X position of the point is the Time
			ShowValue("Accuracy = " + (Mathf.Round(hit.transform.position.y * 100) / 100) + " " + "Time = " + (((hit.transform.position.x / 200) * gridshotClass.get_TaskTime() + 1)));
			//Since in the Gridshot script, we divide 180 (which is the target length of the graph) by the number of seconds the task is (TaskTime)
			//That means that we dont get an accurate reading of the time since the x position of the graph points is no longer the seconds. So to fix that issue we just reverse the
			//Operation that is performed on the x position by /180 then * by task time to get the actual index of the point then we add 1 to compensate for the array starting at index 0
			//(since the player cant hit something on the 0 seconds so it makes sense to start from the first seconds instead)


		}
		if (Physics.Raycast(ray, out hit) && hit.transform.GetComponent<graphPointHoverLinePath>())
		{
			//Same explanation for Accuracy but replace with reaction time instead of accuracy
			ShowValue("HT = " + Mathf.Round(hit.transform.position.y) + "% " + "shot = " + Mathf.FloorToInt(((hit.transform.position.x / 200) * linePathClass.get_graphPoints().Count) + 1));
		}
	}
	private void Awake()
	{
		backgroundRect = transform.Find("background").GetComponent<RectTransform>();
		valueText = transform.Find("value").GetComponent<TextMeshProUGUI>();
		rect = transform.GetComponent<RectTransform>();
		HideValue();
	}

	private void ShowValue(string value)
	{
		//Sets the text to be the value passed through as a parameter
		valueText.SetText(value);
		//Function to force regeneration of the mesh before its normal process time
		valueText.ForceMeshUpdate();
		//Sets the gap between the text and edge of rectangle to be 8 by 8
		Vector2 textGap = new Vector2(8, 8);
		//Sets the size of the text
		Vector2 valueTextSize = valueText.GetRenderedValues(true);
		//Sets the size of the rectangle to be the size of the text + the textgap to make sure the text isnt hugging the edges
		backgroundRect.sizeDelta = valueTextSize + textGap;
	}

	//Hides the text
	private void HideValue()
	{

		gameObject.SetActive(false);
	}
}
