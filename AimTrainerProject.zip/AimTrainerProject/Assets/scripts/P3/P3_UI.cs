using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;


public class P3_UI : MonoBehaviour
{
	Scene currentScene;

	[SerializeField] private P3_GSCONTROLLER gridshotClass;
	[SerializeField] private P3_LP linePathClass;

	[SerializeField] private Camera playerCamera;
	[SerializeField] private Camera graphCamera;

	[SerializeField] private Canvas resultsPage;
	[SerializeField] private Canvas graphCanvas;

	[SerializeField] TextMeshProUGUI accuracyText;
	[SerializeField] TextMeshProUGUI shotsTotalText;
	[SerializeField] TextMeshProUGUI targetsHitText;
	[SerializeField] TextMeshProUGUI errorsizeText;
	[SerializeField] TextMeshProUGUI reactionTimeText;
	[SerializeField] TextMeshProUGUI totalScoreText;

	[SerializeField] TextMeshProUGUI centerGapValueText;
	[SerializeField] TextMeshProUGUI dotSizeValueText;
	[SerializeField] TextMeshProUGUI lineWidthValueText;
	[SerializeField] TextMeshProUGUI lineHeightValueTtext;

	[SerializeField] private Button backToMenuButton;
	[SerializeField] private Button goToGraphButton;
	[SerializeField] private Button restartTaskButton;
	[SerializeField] private Button goToResultsButton;

	[SerializeField] private TextMeshProUGUI timerText;

	private bool paused;
	private bool taskEnded;

	[SerializeField] private RectTransform crosshair;
	[SerializeField] private RectTransform centerDot;

	[SerializeField] private RectTransform topLine;
	[SerializeField] private RectTransform bottomLine;
	[SerializeField] private RectTransform leftLine;
	[SerializeField] private RectTransform rightLine;

	private float dotSize;
	private float centerGap;
	private float lineWidth;
	private float lineHeight;

	[SerializeField] private Canvas feedbackScreen;
	[SerializeReference] private Button goTofeedbackButton;
	[SerializeField] private Button returnToResultsFromFeedbackButton;

	[SerializeField] private TextMeshProUGUI mainFeedbacktext;
	[SerializeField] private TextMeshProUGUI errorsizefeedbacktext;
	[SerializeField] private TextMeshProUGUI targetsHitfeedbackText;
	[SerializeField] private TextMeshProUGUI reactionTimefeedbackText;


	//these attributes store all of the values from the previous task
	private float previousAccuracy;
	private float previousHoverTime;
	private float previousErrorSizeGS;
	private float previousErrorSizeLP;
	private float previousTargetsHitGS;
	private float previousTargetsHitLP;
	private float previousReactionTimeGS;
	private float previousReactionTimeLP;
	private float previousTotalScoreGS;
	private float previousTotalScoreLP;


	private void Start()
	{	
		string[] test = new string[3];

		currentScene = SceneManager.GetActiveScene();

		//sets the default values for the crosshairs
		centerGap = 50;
		lineHeight = 30;
		lineWidth = 10;
		dotSize = 23.5f;

		//all of the button listeners
		goToGraphButton.onClick.AddListener(delegate { goToGraphFromResults(); });
		goToResultsButton.onClick.AddListener(delegate { goToResultsFromGraph(); });
		restartTaskButton.onClick.AddListener(delegate { restartTask(); });
		backToMenuButton.onClick.AddListener(delegate { goToMainMenuFromResults(); });
		goTofeedbackButton.onClick.AddListener(delegate { goToFeedback(); });
		returnToResultsFromFeedbackButton.onClick.AddListener(delegate { goToResultsFromFeedback(); });

		feedbackScreen.gameObject.SetActive(false);
		resultsPage.gameObject.SetActive(false);

		//sets all of the previous task attributes to their values in the registry that was saved from the last task
		previousAccuracy = PlayerPrefs.GetFloat("prevAcc");
		previousHoverTime = PlayerPrefs.GetFloat("prevHT");
		previousErrorSizeGS = PlayerPrefs.GetFloat("prevESg");
		previousErrorSizeLP = PlayerPrefs.GetFloat("prevESl");
		previousTargetsHitGS = PlayerPrefs.GetFloat("prevTHg");
		previousTargetsHitLP = PlayerPrefs.GetFloat("prevTHl");
		previousReactionTimeGS = PlayerPrefs.GetFloat("prevRTg");
		previousReactionTimeLP = PlayerPrefs.GetFloat("prevRTl");
		previousTotalScoreGS = PlayerPrefs.GetFloat("prevSCg");
		previousTotalScoreLP = PlayerPrefs.GetFloat("prevSCl");
	}

	private void Update()
	{	
		//changes which scripts to get the values from depending on which task the user is doing
		if(currentScene.buildIndex == 1)
		{
			timerText.text = Mathf.FloorToInt(gridshotClass.get_TaskTime() - gridshotClass.get_Timer()).ToString("");
			paused = gridshotClass.get_paused();
			taskEnded = gridshotClass.get_taskEnded();
		}
		else if(currentScene.buildIndex == 2)
		{
			timerText.text = Mathf.FloorToInt(linePathClass.get_TaskTime() - linePathClass.get_Timer()).ToString("");
			paused = linePathClass.get_paused();
			taskEnded = linePathClass.get_taskEnded();
		}

	
		centerGapValueText.text = centerGap.ToString();
		dotSizeValueText.text = dotSize.ToString();
		lineWidthValueText.text = lineWidth.ToString();
		lineHeightValueTtext.text = lineHeight.ToString();
		
		//updates the crosshair size every frame based on the values
		crosshair.sizeDelta = new Vector2(centerGap, centerGap);
		centerDot.sizeDelta = new Vector2(dotSize, dotSize);
		topLine.sizeDelta = new Vector2(lineWidth, lineHeight);
		bottomLine.sizeDelta = new Vector2(lineWidth, lineHeight);
		leftLine.sizeDelta = new Vector2(lineHeight, lineWidth);
		rightLine.sizeDelta = new Vector2(lineHeight, lineWidth);

		//buttons run methods when clicked


		if (taskEnded)
		{
			//gets the statistics from the main scripts when the task has ended
			if (currentScene.buildIndex == 1)	
			{	
				//sets the internal values to the values from the other classes
				float accuracy = gridshotClass.get_accuracy();
				float targetsHit = gridshotClass.get_targetsHit();
				float errorSize = gridshotClass.get_errorSize();
				float reactionTime = gridshotClass.get_reactionTime();
				float score = gridshotClass.get_score();

				//runs if the player has completed at least one task previously
				if (PlayerPrefs.HasKey("prevAcc"))
				{	
					//concantenates the strings to show the values for the current run and the last run
					accuracyText.text = gridshotClass.get_accuracy().ToString("F2") + " :::: last try : " + previousAccuracy;
					shotsTotalText.text = gridshotClass.get_shotsTotal().ToString();
					targetsHitText.text = gridshotClass.get_targetsHit().ToString() + " :::: last try : " + previousTargetsHitGS;
					errorsizeText.text = gridshotClass.get_errorSize().ToString("F2") + " :::: last try : " + previousErrorSizeGS;
					reactionTimeText.text = gridshotClass.get_reactionTime().ToString() + " :::: last try : " + previousReactionTimeGS;
					totalScoreText.text = gridshotClass.get_score().ToString()+ " :::: last try : " + Mathf.FloorToInt(previousTotalScoreGS);
				}
				//runs if this is the players first task
				else
				{
					accuracyText.text = gridshotClass.get_accuracy().ToString("F2");
					shotsTotalText.text = gridshotClass.get_shotsTotal().ToString();
					targetsHitText.text = gridshotClass.get_targetsHit().ToString();
					errorsizeText.text = gridshotClass.get_errorSize().ToString("F2");
					reactionTimeText.text = gridshotClass.get_reactionTime().ToString();
					totalScoreText.text = gridshotClass.get_score().ToString();
				}

				//saves the values from this run to the previous values to be shown in the next task
				PlayerPrefs.SetFloat("prevAcc", accuracy);
				PlayerPrefs.SetFloat("prevTHg", targetsHit);
				PlayerPrefs.SetFloat("prevESg", errorSize);
				PlayerPrefs.SetFloat("prevRTg", reactionTime);
				PlayerPrefs.SetFloat("prevSCg", score);


				

			
				//gives feedback on the different statistics
				switch (accuracy)
				{	
					//first case is the best performance one
					case var expression when (accuracy > 95):
						mainFeedbacktext.text = "accuracy : your accuracy was above 95%! this is good as it means you are making sure you hit the target instead of sacrificing accuracy for speed, well done! this means that you are able to shoot the enemies more accurately which allows you to improve in game";
						break;

					//second case is when the player performs average
					case var expression when (accuracy > 80 && accuracy < 95):
						mainFeedbacktext.text = "accuracy : your accuracy was between 80 and 95%! this is a good range as it means you are hitting the targets accurately however, you might be sacrificing accuracy for speed a little bit. This means that in game you might be missing some shots on the enemies which may hinder your score and performance. to improve, make sure you arent rushing and take time to hit the targets!";
						break;

					//third case is when the player performs below average
					case var expression when (accuracy < 80):
						mainFeedbacktext.text = "accuracy : your accuracy was below 80%. this means that you are rushing your shots and not lining them up correctly. This means that in game, you miss more of your shots on the enemies which may lead to more losses of games. to improve, make sure you take a bit more time on each shot because speed scales with accuracy so the more you practice hitting your shots, the quicker you'll get!";
						break;
				}

				switch (targetsHit)
				{
					case var expression when (targetsHit > 300):
						targetsHitfeedbackText.text = "targetsHit : You destroyed more than 300 targets! this means that you are able to react to and shoot lots of targets in very quick succession. This means that you can react to the enemies quicker than they can react to you which helps lots in game! Well Done!";
						break;
					case var expression when (targetsHit > 200 && targetsHit < 300):
						targetsHitfeedbackText.text = "targetsHit : You destroyed between 200 and 300 targets! This means that you are able to react to and destroy targets quite efficiently. This means that you are able to react to enemies quickly, but may be beat out by other enemies. In order to improve, try to stay more consistent with your speed";
						break;
					case var expression when (targetsHit < 200):
						targetsHitfeedbackText.text = "targetsHit : You destroyed less than 200 targets. This means that you are most likely trying to rush too much and ending up missing lots of targets. This means that a lot of the times, the enemies may react quicker which means they beat you in gunfights a lot. Best way to improve this would be to try to shoot the targets at a consistent speed which will allow you to improve both your accuracy and your targetsHit";
						break;
				}
				switch (errorSize)
				{
					case var expression when (errorSize < 1.5):
						errorsizefeedbacktext.text = "errorSize : your errorSize was below 1.5! this means that you are able to hit near the centre of the target each time, this is good because aiming close to the center gives you the best chance of hitting the target!. In game this means that you are able to hit the enemies head much more efficiently than most";
						break;
					case var expression when (errorSize > 1.5 && errorSize < 2):
						errorsizefeedbacktext.text = "errorsize : your errorSize was between 1.5 and 2!. this means that you are able to hit close to the center most times. to improve, try to practice hitting similar places consistently!"; ;
						break;
					case var expression when (errorSize > 2):
						errorsizefeedbacktext.text = "errorsize : your errorSize was above 2. This means that you are rushing your shots too much and hitting close to the outer edge, this means that you have a higher chance of missing the target. To improve, take more time lining up the shots and make sure not to rush it too much";
						break;

				}
				switch (reactionTime)
				{
					case var expression when (reactionTime < 200):
						reactionTimefeedbackText.text = "reactionTime : your reaction time was below 200ms!. This means that you are able to react to enemies much faster than average which will allow you to win more gunfights!";
						break;
					case var expression when (reactionTime < 200 && reactionTime > 300):
						reactionTimefeedbackText.text = "reactionTime : your reaction time was between 200 and 300ms!. this means that you are able to react to targets quickly most of the time. To improve, try to pace yourself and stay consistent!";
						break;
					case var expression when (reactionTime > 300):
						reactionTimefeedbackText.text = "reactionTime : your reaction time was above 300ms. This means that you are most likely not shooting targets at a decent pace. in order to improve, try to pace yourself and stay consistent with the timing between shots";
						break;
				}
			}
			else if (currentScene.buildIndex == 2)
			{
				float hoverTime = linePathClass.get_hoverTime();
				float  targetsHit = linePathClass.get_targetsHit();
				float errorSize = linePathClass.get_errorSize();
				float reactionTime = linePathClass.get_reactionTime();
				float score = linePathClass.get_score();

				

				if (PlayerPrefs.HasKey("prevHT"))
				{
					accuracyText.text = linePathClass.get_hoverTime().ToString("F2") + " :::: last try : " + previousHoverTime;
					shotsTotalText.text = linePathClass.get_shotsTotal().ToString();
					targetsHitText.text = linePathClass.get_targetsHit().ToString() + " :::: last try : " + previousTargetsHitLP;
					errorsizeText.text = linePathClass.get_errorSize().ToString("F2") + " :::: last try : " + previousErrorSizeLP;
					reactionTimeText.text = linePathClass.get_reactionTime().ToString() + " :::: last try : " + previousReactionTimeLP;
					totalScoreText.text = linePathClass.get_score().ToString()+" :::: last try : " + Mathf.FloorToInt(previousTotalScoreLP);
				} 
				else
				{
					accuracyText.text = linePathClass.get_avgPercent().ToString("F2");
					shotsTotalText.text = linePathClass.get_shotsTotal().ToString();
					targetsHitText.text = linePathClass.get_targetsHit().ToString();
					errorsizeText.text = linePathClass.get_errorSize().ToString("F2");
					reactionTimeText.text = linePathClass.get_reactionTime().ToString();
					totalScoreText.text = linePathClass.get_score().ToString();
				}

				PlayerPrefs.SetFloat("prevHT", hoverTime);
				PlayerPrefs.SetFloat("prevTHl", targetsHit);
				PlayerPrefs.SetFloat("prevESl", errorSize);
				PlayerPrefs.SetFloat("prevRTl", reactionTime);
				PlayerPrefs.SetFloat("prevSCl", score);

				//feedback
				switch (hoverTime)
				{
					case var expression when (hoverTime > 75):
						mainFeedbacktext.text = "hover time : your hover time was above 75%!. this means that you are able to move between targets in a relatively straight line which means you can go from target to target quite quickly!";
						break;

					case var expression when (hoverTime > 40 && hoverTime < 75):
						mainFeedbacktext.text = "hover time : your hover time was between 40 and 75%! this means that you are able to stay on the line a decent amount. To improve, try to take a bit more time and stay consistent with the tracing";
						break;

					case var expression when (hoverTime < 40):
						mainFeedbacktext.text = "hover time : your hover time was below 40%. This means that you are trying to rush between targets which means that you arent travelling in a straight line. to improve, try to take more time and care to move in a straight line, the more you practice, the faster you will get.";
						break;
				}

				switch (targetsHit)
				{
					case var expression when (targetsHit > 300):
						targetsHitfeedbackText.text = "targetsHit : You destroyed more than 300 targets! this means that you are able to react to and shoot lots of targets in very quick succession. This means that you can react to the enemies quicker than they can react to you which helps lots in game! Well Done!";
						break;
					case var expression when (targetsHit > 200 && targetsHit < 300):
						targetsHitfeedbackText.text = "targetsHit : You destroyed between 200 and 300 targets! This means that you are able to react to and destroy targets quite efficiently. This means that you are able to react to enemies quickly, but may be beat out by other enemies. In order to improve, try to stay more consistent with your speed";
						break;
					case var expression when (targetsHit < 200):
						targetsHitfeedbackText.text = "targetsHit : You destroyed less than 200 targets. This means that you are most likely trying to rush too much and ending up missing lots of targets. This means that a lot of the times, the enemies may react quicker which means they beat you in gunfights a lot. Best way to improve this would be to try to shoot the targets at a consistent speed which will allow you to improve both your accuracy and your targetsHit";
						break;
				}
				switch (errorSize)
				{
					case var expression when (errorSize < 1.5):
						errorsizefeedbacktext.text = "errorSize : your errorSize was below 1.5! this means that you are able to hit near the centre of the target each time, this is good because aiming close to the center gives you the best chance of hitting the target!. In game this means that you are able to hit the enemies head much more efficiently than most";
						break;
					case var expression when (errorSize > 1.5 && errorSize < 2):
						errorsizefeedbacktext.text = "errorsize : your errorSize was between 1.5 and 2!. this means that you are able to hit close to the center most times. to improve, try to practice hitting similar places consistently!"; ;
						break;
					case var expression when (errorSize > 2):
						errorsizefeedbacktext.text = "errorsize : your errorSize was above 2. This means that you are rushing your shots too much and hitting close to the outer edge, this means that you have a higher chance of missing the target. To improve, take more time lining up the shots and make sure not to rush it too much";
						break;

				}
				switch (reactionTime)
				{
					case var expression when (reactionTime < 200):
						reactionTimefeedbackText.text = "reactionTime : your reaction time was below 200ms!. This means that you are able to react to enemies much faster than average which will allow you to win more gunfights!";
						break;
					case var expression when (reactionTime < 200 && reactionTime > 300):
						reactionTimefeedbackText.text = "reactionTime : your reaction time was between 200 and 300ms!. this means that you are able to react to targets quickly most of the time. To improve, try to pace yourself and stay consistent!";
						break;
					case var expression when (reactionTime > 300):
						reactionTimefeedbackText.text = "reactionTime : your reaction time was above 300ms. This means that you are most likely not shooting targets at a decent pace. in order to improve, try to pace yourself and stay consistent with the timing between shots";
						break;
				}	
			}
		}
	}
	public void goToGraphFromResults()
	{
		resultsPage.gameObject.SetActive(false);
		graphCanvas.gameObject.SetActive(true);
	}
	public void goToMainMenuFromResults()
	{
		SceneManager.LoadScene(sceneBuildIndex: 0);
	}
	
	public void restartTask()
	{
		SceneManager.LoadScene(sceneBuildIndex: currentScene.buildIndex);
	}

	public void goToResultsFromGraph()
	{
		resultsPage.gameObject.SetActive(true);
		graphCanvas.gameObject.SetActive(false);
	}

	public void goToFeedback()
	{
		resultsPage.gameObject.SetActive(false);
		feedbackScreen.gameObject.SetActive(true);
	}

	public void goToResultsFromFeedback()
	{
		resultsPage.gameObject.SetActive(true);
		feedbackScreen.gameObject.SetActive(false);
	}
	//SETTERS
	public void set_dotSize(float value) 
	{
		dotSize = value;
	}
	public void set_centerGap(float value)
	{
		centerGap = value;
	}
	public void set_lineWidth(float value)
	{
		lineWidth = value;
	}
	
	public void set_lineHeight(float value)
	{
		lineHeight = value;
	}

	public float get_dotSize()
	{
		return dotSize;
	}
	public float get_centerGap()
	{
		return centerGap;
	}
	public float get_lineWidth()
	{
		return lineWidth;
	}
	public float get_lineHeight()
	{
		return lineHeight;
	}
	//SETTERS
}
