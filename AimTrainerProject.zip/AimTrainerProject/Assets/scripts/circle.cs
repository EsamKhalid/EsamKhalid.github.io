using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class circle : MonoBehaviour
{
    private GameObject[] objs;
    [Range(0,100)]
    [SerializeField] private int numberOfPoints;

    [Range(0, 100)]
    [SerializeField] private float radius;
    private Vector3 circleCenter;

    private GameObject[] polygons;
    private GameObject[] lines;
    [SerializeField] private int numPoints;

    [SerializeField] private float val1;
    [SerializeField] private float val2;
    [SerializeField] private float val3;
    [SerializeField] private float val4;
    [SerializeField] private float val5;
    private float[] valArray;
    private GameObject[] meshPoints;
    private GameObject[] meshLines;
    private int meshPointNum;

    [SerializeField] private GameObject meshParent;


    // Start is called before the first frame update
    void Start()
    {   
        
        objs = new GameObject[numberOfPoints];
        polygons = new GameObject[numPoints];
        lines = new GameObject[polygons.Length + 1];
        meshPoints = new GameObject[numPoints];
        meshLines = new GameObject[meshPoints.Length];

        createCricle(radius, numberOfPoints);
        createPolygon(radius,numPoints);
        drawLines();

    

        valArray = new float[5];

        //val1 = Random.Range(0, 100);
        //val2 = Random.Range(0, 100);
        //val3 = Random.Range(0, 100);
        //val4 = Random.Range(0, 100);
        //val5 = Random.Range(0, 100);

        //valArray[0] = val1;
        //valArray[1] = val2;
        //valArray[2] = val3;
        //valArray[3] = val4;
        //valArray[4] = val5;

        
    }

    private void Update()
    {


		

		if (Input.GetKeyDown(KeyCode.Space))
		{
            for (int i = 0; i < valArray.Length; i++)
            {
                valArray[i] = Random.Range(0, 100);
            }

            foreach (Transform obj in meshParent.transform)
			{
				Destroy(obj.gameObject);
			}


			for (int i = 0; i < polygons.Length; i++)
			{
				createMeshPoints(valArray[i], polygons[i], i);
			}

			drawMeshLines();
		}

	}


	private void createCricle(float radius, int numberOfPoints)
    {
        for(int i = 0; i < numberOfPoints; i++)
		{
            float angle = i * (Mathf.PI * 2) / numberOfPoints;
            float x = Mathf.Cos(angle) * radius;
            float y = Mathf.Sin(angle) * radius;
            objs[i] = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            objs[i].transform.position = new Vector3(x, y, 0);

           // Debug.Log(Mathf.Cos( 0 * (Mathf.PI * 2) / numberOfPoints) * radius);
		}
    }

    private void createPolygon(float radius, float numPoints)
	{
        float circ = 1 / numPoints;
        float radian = circ * (2 * Mathf.PI);

        for(int i = 0; i < numPoints; i++)
		{
            float angle = radian * i;
            float x = Mathf.Cos(angle) * radius;
            float y = Mathf.Sin(angle) * radius;
            polygons[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            polygons[i].transform.position = new Vector3(x, y, 0);
            polygons[i].transform.localScale = new Vector3(2, 2, 2);
		}

        circleCenter = new Vector3(polygons[0].transform.position.x - radius, 0, 0);

    }




    private void createMeshPoints(float value, GameObject point, int index)
	{
        float normalizer;
        //normalizer = (value - Mathf.Min(valArray)) / (Mathf.Max(valArray) - Mathf.Min(valArray));
        normalizer = value / radius;
        meshPoints[index] = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        meshPoints[index].transform.localScale = new Vector3(3, 3, 3);
        meshPoints[index].transform.parent = meshParent.transform;
        if(normalizer > 1)
		{
            meshPoints[index].transform.position = (point.transform.position + circleCenter) / normalizer;
        }
		else
		{
            meshPoints[index].transform.position = (point.transform.position + circleCenter) * normalizer;
        }
        Debug.Log(value);
        //meshPointNum += 1;
    }




    private void drawLines()
	{
        for (int i = 0; i < lines.Length + 1; i++)
		{   
            if(i == polygons.Length - 1)
			{
                lines[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
                lines[i].transform.position = (polygons[i].transform.position + polygons[0].transform.position) / 2;
                lines[i].transform.localScale = new Vector3(1, Vector2.Distance(polygons[i].transform.position, polygons[0].transform.position), 1);
                lines[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, polygons[0].transform.position - polygons[i].transform.position);
            }
			else if(i < polygons.Length)
			{
                lines[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
                lines[i].transform.position = (polygons[i].transform.position + polygons[i + 1].transform.position) / 2;
                lines[i].transform.localScale = new Vector3(1, Vector2.Distance(polygons[i].transform.position, polygons[i + 1].transform.position), 1);
                lines[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, polygons[i + 1].transform.position - polygons[i].transform.position);
            }

            

        }

    }


    private void drawMeshLines()
	{
        for (int i = 0; i < lines.Length + 1; i++)
        {
            if (i == meshPoints.Length - 1)
            {
                meshLines[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
                meshLines[i].transform.position = (meshPoints[i].transform.position + meshPoints[0].transform.position) / 2;
                meshLines[i].transform.localScale = new Vector3(1, Vector2.Distance(meshPoints[i].transform.position, meshPoints[0].transform.position), 1);
                meshLines[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, meshPoints[0].transform.position - meshPoints[i].transform.position);
                meshLines[i].transform.parent = meshParent.transform;
            }
            else if (i < meshPoints.Length)
            {
                meshLines[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
                meshLines[i].transform.position = (meshPoints[i].transform.position + meshPoints[i + 1].transform.position) / 2;
                meshLines[i].transform.localScale = new Vector3(1, Vector2.Distance(meshPoints[i].transform.position, meshPoints[i + 1].transform.position), 1);
                meshLines[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, meshPoints[i + 1].transform.position - meshPoints[i].transform.position);
                meshLines[i].transform.parent = meshParent.transform;
            }

            

        }

    }

}
