using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class nt1 : MonoBehaviour
{

    private List<Vector2> gp = new List<Vector2>();
    private Vector2[] gp2;



    void Start()
    {
        gp.Add(new Vector2(1, 2));
        Vector2 test = gp[0];
        test.x = 10;
        test.y = 20;
        gp[0] = test;
        gp2 = gp.ToArray();

        foreach(Vector2 item in gp2)
		{
            Debug.Log(item);
            Debug.Log(gp2.Length);
		}

        
    }

	private void Update()
	{
       

    }


   

	

    
}


