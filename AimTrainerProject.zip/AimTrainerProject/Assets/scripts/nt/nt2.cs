using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class nt2 : MonoBehaviour
{
	
	private void Start()
	{
		
		
		

	}


	private void Update()
	{

		

	}



	

}
