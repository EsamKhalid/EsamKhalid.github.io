using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;


public class P2_UI : MonoBehaviour
{
	Scene currentScene;

	[SerializeField] private P2_GSCONTROLLER gridshotClass;
	[SerializeField] private P2_LP linePathClass;

	[SerializeField] private Camera playerCamera;
	[SerializeField] private Camera graphCamera;

	[SerializeField] private Canvas resultsPage;
	[SerializeField] private Canvas graphCanvas;

	[SerializeField] TextMeshProUGUI accuracyText;
	[SerializeField] TextMeshProUGUI shotsTotalText;
	[SerializeField] TextMeshProUGUI targetsHitText;
	[SerializeField] TextMeshProUGUI errorsizeText;
	[SerializeField] TextMeshProUGUI reactionTimeText;

	[SerializeField] TextMeshProUGUI centerGapValueText;
	[SerializeField] TextMeshProUGUI dotSizeValueText;
	[SerializeField] TextMeshProUGUI lineWidthValueText;
	[SerializeField] TextMeshProUGUI lineHeightValueTtext;

	[SerializeField] private Button backToMenuButton;
	[SerializeField] private Button goToGraphButton;
	[SerializeField] private Button restartTaskButton;
	[SerializeField] private Button goToResultsButton;

	[SerializeField] private TextMeshProUGUI timerText;

	private bool paused;
	private bool taskEnded;

	[SerializeField] private RectTransform crosshair;
	[SerializeField] private RectTransform centerDot;

	[SerializeField] private RectTransform topLine;
	[SerializeField] private RectTransform bottomLine;
	[SerializeField] private RectTransform leftLine;
	[SerializeField] private RectTransform rightLine;

	private float dotSize;
	private float centerGap;
	private float lineWidth;
	private float lineHeight;

	private void Start()
	{
		currentScene = SceneManager.GetActiveScene();

		//sets the default values for the crosshairs
		centerGap = 50;
		lineHeight = 30;
		lineWidth = 10;
		dotSize = 23.5f;
	}
	private void Update()
	{	
		//changes which scripts to get the values from depending on which task the user is doing
		if(currentScene.buildIndex == 1)
		{
			timerText.text = Mathf.FloorToInt(gridshotClass.get_TaskTime() - gridshotClass.get_Timer()).ToString();
			paused = gridshotClass.get_paused();
			taskEnded = gridshotClass.get_taskEnded();
		}
		else if(currentScene.buildIndex == 2)
		{
			timerText.text = Mathf.FloorToInt(linePathClass.get_TaskTime() - linePathClass.get_Timer()).ToString();
			paused = linePathClass.get_paused();
			taskEnded = linePathClass.get_taskEnded();
		}

	
		centerGapValueText.text = centerGap.ToString();
		dotSizeValueText.text = dotSize.ToString();
		lineWidthValueText.text = lineWidth.ToString();
		lineHeightValueTtext.text = lineHeight.ToString();
		
		//updates the crosshair size every frame based on the values
		crosshair.sizeDelta = new Vector2(centerGap, centerGap);
		centerDot.sizeDelta = new Vector2(dotSize, dotSize);
		topLine.sizeDelta = new Vector2(lineWidth, lineHeight);
		bottomLine.sizeDelta = new Vector2(lineWidth, lineHeight);
		leftLine.sizeDelta = new Vector2(lineHeight, lineWidth);
		rightLine.sizeDelta = new Vector2(lineHeight, lineWidth);

		//buttons run methods when clicked
		goToGraphButton.onClick.AddListener(delegate { goToGraphFromResults(); });
		goToResultsButton.onClick.AddListener(delegate { goToResultsFromGraph(); });
		restartTaskButton.onClick.AddListener(delegate { restartTask(); });
		backToMenuButton.onClick.AddListener(delegate { goToMainMenuFromResults(); });

		if (taskEnded)
		{
			//gets the statistics from the main scripts when the task has ended
			if (currentScene.buildIndex == 1)
			{
				accuracyText.text = gridshotClass.get_accuracy().ToString("F2");
				shotsTotalText.text = gridshotClass.get_shotsTotal().ToString();
				targetsHitText.text = gridshotClass.get_targetsHit().ToString();
				errorsizeText.text = gridshotClass.get_errorSize().ToString("F2");
				reactionTimeText.text = gridshotClass.get_reactionTime().ToString();
			}
			else if (currentScene.buildIndex == 2)
			{	
				accuracyText.text = linePathClass.get_avgPercent().ToString("F2");
				shotsTotalText.text = linePathClass.get_shotsTotal().ToString();
				targetsHitText.text = linePathClass.get_targetsHit().ToString();
				errorsizeText.text = linePathClass.get_errorSize().ToString("F2");
				reactionTimeText.text = linePathClass.get_reactionTime().ToString();
			}
		}
	}
	public void goToGraphFromResults()
	{
		resultsPage.gameObject.SetActive(false);
		graphCanvas.gameObject.SetActive(true);
	}
	public void goToMainMenuFromResults()
	{
		SceneManager.LoadScene(sceneBuildIndex: 0);
	}
	
	public void restartTask()
	{
		SceneManager.LoadScene(sceneBuildIndex: currentScene.buildIndex);
	}

	public void goToResultsFromGraph()
	{
		resultsPage.gameObject.SetActive(true);
		graphCanvas.gameObject.SetActive(false);
	}

	//SETTERS
	public void set_dotSize(float value) 
	{
		dotSize = value;
	}
	public void set_centerGap(float value)
	{
		centerGap = value;
	}
	public void set_lineWidth(float value)
	{
		lineWidth = value;
	}
	
	public void set_lineHeight(float value)
	{
		lineHeight = value;
	}
	//SETTERS
}
