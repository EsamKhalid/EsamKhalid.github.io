using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
public class P2_GSCONTROLLER : MonoBehaviour
{
    [SerializeField] private P2_OPT optionsClass;

    [SerializeField] private GameObject graphBackground;
    [SerializeField] private Canvas resultsPage;

    private float damage = 10f;
    private float range = 100f;

    [SerializeField] private GameObject gun;
    [SerializeField] private GameObject playerCharacter;
    [SerializeField] private Camera playerCamera;
    [SerializeField] private LayerMask Player;

   

    //STATS 
    private Vector3 shotPosition;
    private float errorSize;

    private float shotsTotal;
    private float targetsHit;

    private float accuracy;

    private float totalScore    ;

    private float targetsHitInSecond;

    private float totalReactionTime;
    //STATS 


    //TIME
    private float time;
    private float timer;

    private int secondsPassed;
    private int taskTime = 1;

	private bool taskEnded = false;
	private bool paused;

	private bool preGame = true;
	private bool pregametimerbool; 
	private float pregametimer = 0;
    //TIME


    //GRAPH
    [SerializeField] private Camera graphCamera;
    [SerializeField] private Canvas graphCanvas;
    private Vector2[] graphPoints;
    //GRAPH

    //Gridshot vars
    private int TotalTargetsSpawned = 0; //Used to be TotalTargets
    private int MaxTargetsSpawned = 3; //Used to be TargetCount

    private Vector3 startspawn;

    [SerializeField] private GameObject spawn1;
    [SerializeField] private GameObject spawn2;
    [SerializeField] private GameObject spawn3;
    [SerializeField] private GameObject spawn4;
    [SerializeField] private GameObject spawn5;
    [SerializeField] private GameObject spawn6;
    [SerializeField] private GameObject spawn7;
    [SerializeField] private GameObject spawn8;
    [SerializeField] private GameObject spawn9;

    private List<GameObject> Spawned = new List<GameObject>();
    private List<Vector3> Available = new List<Vector3>();
    private List<Vector3> justDestroyed = new List<Vector3>();
    //End Gridshot vars

    private void Start()
    {   
        //adding all of the possible spawn locations into the available list
        Available.Add(spawn1.transform.position);
        Available.Add(spawn2.transform.position);
        Available.Add(spawn3.transform.position);
        Available.Add(spawn4.transform.position);
        Available.Add(spawn5.transform.position);
        Available.Add(spawn6.transform.position);
        Available.Add(spawn7.transform.position);
        Available.Add(spawn8.transform.position);
        Available.Add(spawn9.transform.position);

        //setting the max framerate to 60
        Application.targetFrameRate = 60;
        
        //initialising the graphPoints array to be the same lengh as the number of seconds
        graphPoints = new Vector2[taskTime];
    }

    void Update()
    {
        //gets the paused bool from the optionsclass every frame
        paused = optionsClass.get_paused();
        preGame = optionsClass.get_preGame();

        //counts down the timers only when the game isnt paused and not in pregame state
		if (!paused && !preGame)
		{
            time += Time.deltaTime;
            timer += Time.deltaTime;
        }

        //if the player's y position reaches a certain value
        if (playerCharacter.transform.position.y <= -20)
        {   
            //resets the player's position
            playerCharacter.transform.position = new Vector3(-111f, 2f, -19f);

        }

       
        //when the fire button is clicked it calls the shoot() function
        if (Input.GetButtonDown("Fire1"))
        {   
            //only calls shoot when the game isnt paused or in pregame state
            if(!preGame && !paused && !taskEnded)
			{
                shoot();
			}
        }

        

       
        //while there are less targets than the max
        while (TotalTargetsSpawned < MaxTargetsSpawned)
        {   
            //generates a random index between 0 and the length of the list that hold the available spawn positions

            spawnTargets(Random.Range(0,Available.Count));
        }

        //if at least one second has passed, it generatest he graph positions every second
        if (time > 1)
        {
            generateAccuracyGraphPositions();

            secondsPassed += 1;
            time = 0;
        }

        //calls the endtask method when secondspassed becomes greater than the task time
        if(secondsPassed >= taskTime && !taskEnded)
		{
            endTask();
		}

      
    }
    private void generateAccuracyGraphPositions()
    {   
        //calculates accuracy using targetshit and shotstotal as a percentage
        accuracy = (targetsHit / shotsTotal) * 100;
        
        //if the timepassed since the start is less than the length of the graph(aka the total time of the task)
        if(secondsPassed < graphPoints.Length)
		{
            //sets the index of the graphpoints as the second that it is calculated on
            graphPoints[secondsPassed].y = accuracy;
		}
    }

    private void endTask()
    {
        taskEnded = true;
        resultsPage.gameObject.SetActive(true);
		playerCamera.gameObject.SetActive(false);
		graphCamera.gameObject.SetActive(true);
        accuracy = (targetsHit / shotsTotal) * 100;
        errorSize /= targetsHit;
        totalReactionTime = (taskTime / targetsHit) * 1000;
        Cursor.lockState = CursorLockMode.None;
		Cursor.visible = true;
        Debug.Log("accuracy = " + accuracy);
        Debug.Log("errorsize = " + errorSize);
        Debug.Log("shotsTotal = " + shotsTotal);
        Debug.Log("targetsHit = " + targetsHit);
        Debug.Log("reactionTime = " + totalReactionTime);
	}

    private void spawnTargets(int index)
    {   
        //if at least one target has been hit
        if (targetsHit > 1)
        {   
            //adds the 0 index of justdestroyed to available since that is the spawn position that has been spawned the furthest spawn cycles away from the current spawn cycle
            Available.Add(justDestroyed[0]);
            //removes that spawn position from just destroyed
            justDestroyed.Remove(justDestroyed[0]);
        }

        //creates an empty sphere
        Spawned.Add(GameObject.CreatePrimitive(PrimitiveType.Sphere));
        //Adds the chosen index of available to the list of spawned targets
        Spawned[TotalTargetsSpawned].transform.position = Available[index];
        //sets the size of the sphere to be 4.5x larger than default
        Spawned[TotalTargetsSpawned].transform.localScale = new Vector3(4.5f, 4.5f, 4.5f);

        //Spawned[TotalTargetsSpawned].transform.GetComponent<SphereCollider>().
        //adds the target script onto the target
        Spawned[TotalTargetsSpawned].AddComponent<P2_TARGET>();
        //changes the target colour to black
        Spawned[TotalTargetsSpawned].GetComponent<Renderer>().material.color = Color.black;
        //Removes the chosen spawn position from the available list since there is now a target in that position and it is no longer available
        Available.Remove(Available[index]);
        //Increments TotalTargetsSpawned by 1 for the counter controlled loop
        TotalTargetsSpawned += 1;

        
    }
    private void shoot()
    {   
        //increments shots total by 1 for stats
        shotsTotal += 1;
        RaycastHit shotHit;

        //Returns true if the raycast hits an object
        if (Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward, out shotHit, range, ~Player))
        {
            //Checks the GameObject that has been hit to see if it has a "Target" Script on it and gets that instance of the class
            P2_TARGET target = shotHit.transform.GetComponent<P2_TARGET>();

            //If the GameObject does have a target script on it, cause the target to take damage
            if (target != null)
            {   
                //tells the target to take damage using the public method in the class
                target.takedamage(damage);
                //increments targetshit by 1 for stats
                targetsHit += 1;
                //decrements totaltargetsspawned by 1 to allow for another target to be spawned
                TotalTargetsSpawned -= 1;
                shotPosition = shotHit.point;
                //adds the destroyed target to justdestroyed so it cant be spawned again sraight after
                justDestroyed.Add(shotHit.transform.position);
                //removes the target from spawned since it is no longer spawned in
                Spawned.Remove(shotHit.transform.gameObject);
                //adds the distance between the shot and the center of the target to the errosize value for stats
                errorSize += Vector2.Distance(shotHit.transform.position, shotPosition);

                //errorSize += shotPosition.x - shotHit.transform.position.x;
                //errorSize += shotPosition.y - shotHit.transform.position.y;


 
                Debug.Log(errorSize);
            }
        }

    }
    //SETTERS
    public void set_paused(bool state)
	{
        paused = state;
	}

    public void set_preGame(bool state)
	{
        preGame = state;
	}
    //SETTERS

    //GETTERS
    public bool get_paused()
	{
        return paused;
	}
    public bool get_preGame()
	{
        return preGame;
	}
    public bool get_taskEnded()
    {
        return taskEnded;
    }
    public Vector2[] get_graphPoints()
	{
        return graphPoints;
	}
    public float get_Timer()
	{
        return timer;
	}
    public int get_TaskTime()
	{
        return taskTime;
	}

    public float get_accuracy()
	{
        return accuracy;
	}
    public float get_errorSize()
    {
        return errorSize;
    }
    public float get_reactionTime()
    {
        return totalReactionTime;
    }

    public float get_shotsTotal()
    {
        return shotsTotal;
    }

    public float get_targetsHit()
    {
        return targetsHit;
    }
    //GETTERS
}
