using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class P2_TARGET : MonoBehaviour
{
	//target health
	private float health = 10f;

	//called when target is shot
	public void takedamage(float damage)
	{
		//reduces health by value passed through
		health -= damage;
		//if health reaches 0 call die method
		if (health <= 0)
		{
			Die();
		}
		//destroys the target when called
		void Die()
		{
			Destroy(gameObject);
		}
	}
}
