using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class P2_GRAPH : MonoBehaviour
{
    [SerializeField] private P2_GSCONTROLLER gridshotClass;
    [SerializeField] private P2_LP linePathClass;

    private GameObject[] graphObjects;
    private GameObject[] graphLines;
    private GameObject graphParent;

    private Vector2[] graphPoints;
    
    private float pointDistance;
    private float xValue;

    private bool taskEnded;
    private bool graphGenerated = false;

	private void Update()
	{ 
        if(SceneManager.GetActiveScene().buildIndex == 1)
		{
            taskEnded = gridshotClass.get_taskEnded();
        }
        else if(SceneManager.GetActiveScene().buildIndex == 2)
		{
            taskEnded = linePathClass.get_taskEnded();
        }
        
        if (taskEnded && !graphGenerated)
        {
            if (SceneManager.GetActiveScene().buildIndex == 1)
            {
                graphPoints = gridshotClass.get_graphPoints();

            }
            else if (SceneManager.GetActiveScene().buildIndex == 2)
            {
                graphPoints = linePathClass.get_graphPoints().ToArray();
            }
            //Initiates the arrays for storing the physical points and lines of the graph
            graphLines = new GameObject[graphPoints.Length];
            graphObjects = new GameObject[graphPoints.Length];
            //runs the methods to generate the graph
            generateXPositions(200);
            generateGraphPoints();
            generateGraphLines();
            //sets graph generated to true to prevent the graph from generating again if not needed
            graphGenerated = true;


        }
	}
	private void generateXPositions(float maxDistance)
	{
        //calculates the distance between each point using the number of points and total graph distance
        pointDistance = maxDistance / graphPoints.Length;

        for (int i = 0; i < graphPoints.Length; i++)
        {
            //loops through the array and sets the x position to be equal to the calculated distance
            graphPoints[i].x = xValue;
            xValue += pointDistance;
            
        }
    }
    private void generateGraphPoints()
    {
        for (int i = 0; i < graphPoints.Length; i++)
        {
            //loops through the list and sets the i index of each one to a sphere
            graphObjects[i] = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            //sets the position to be equal to the same index in graph points
            graphObjects[i].transform.position = graphPoints[i];
            //makes the sphere 3x bigger
            graphObjects[i].transform.localScale = new Vector3(3f, 3f, 3f);
            //depending on which task it is, adds different scripts to display different values when hovering over the point
            if (SceneManager.GetActiveScene().buildIndex == 1)
            {
                graphObjects[i].AddComponent<graphPointHoverAccuracy>();
            }
            else if (SceneManager.GetActiveScene().buildIndex == 2)
            {
                graphObjects[i].AddComponent<graphPointHoverLinePath>();
            }
            
        }
    }
    private void generateGraphLines()
    {
        for (int i = 0; i < graphPoints.Length - 1; i++)
        {
            //sets the current index to be a cube
            graphLines[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            //sets the position to be in between current and next index
            graphLines[i].transform.position = (graphPoints[i] + graphPoints[i + 1]) / 2;
            //sets the size to be equal to the distance between the current and next point
            graphLines[i].transform.localScale = new Vector3(1, Vector2.Distance(graphPoints[i], graphPoints[i + 1]), 1);
            //rotates the cube to go from one point to the next
            graphLines[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, graphPoints[i + 1] - graphPoints[i]);
        }
    }
}
