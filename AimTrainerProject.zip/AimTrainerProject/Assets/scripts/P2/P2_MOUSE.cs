using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class P2_MOUSE : MonoBehaviour
{
    [SerializeField] private P2_GSCONTROLLER gridshotClass;
    [SerializeField] private P2_LP linePathClass;

    private float sens = 125f;
    private float tempsense;
    private float ADSmultiplier = 0.75f;
    private bool paused;

    private Transform playerbody;

    [SerializeField] private GameObject player;

    private float xrotation = 0f;

    private float CamFOV = 60f;
    private float tempFOV;

    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = true;
        tempsense = sens;
        tempFOV = CamFOV;

        playerbody = player.transform;
    }
    // Update is called once per frame
    void Update()
    {
        //changes which script to use the getter from depending on which task the user is doung
        if(SceneManager.GetActiveScene().buildIndex == 1)
		{
            
            paused = gridshotClass.get_paused();
        }
        else if(SceneManager.GetActiveScene().buildIndex == 2)
		{
            
            paused = linePathClass.get_paused();
		}

        if (!paused)//If not paused
        {
            //Gets the X input and multiplies it by the sens for the speed and Time.deltaTime to make the camera movement frame independant
            float mouseX = Input.GetAxis("Mouse X") * sens * Time.deltaTime;
            //Gets the X input and multiplies it by the sens for the speed and Time.deltaTime to make the camera movement frame independant
            float mouseY = Input.GetAxis("Mouse Y") * sens * Time.deltaTime;
            //Takes x rotation from mouseY because if it was equal, the rotation of the camera would be flipped compared to the Y input since it is rotating around the X axis
            xrotation -= mouseY;
            //Clamps the rotation of the camera around the X axis to make sure that the player cant look too far behind or too far down
            xrotation = Mathf.Clamp(xrotation, -90f, 90f);
            //Rotates the camera using quaternion and euler angles around the X axis to allow the camera to look up and down
            transform.localRotation = Quaternion.Euler(xrotation, 0f, 0f);
            //Applies a rotation transformation on the up vector(y vector) of the playerbody to rotate it around the y axis to look left and right
            playerbody.Rotate(Vector3.up * mouseX);

            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        if (Input.GetMouseButtonDown(1))
        {
            CamFOV *= 0.75f;
            sens = sens * ADSmultiplier;
        }

        if (Input.GetMouseButtonUp(1)) // rohannn:)
        {
            CamFOV /= 0.75f;
            sens /= ADSmultiplier;

        }

        if (paused)
        {
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
        }

        //changes the main camera's FOV every frame to update it when it changes
        Camera.main.fieldOfView = CamFOV;
    }

    //SETTERS
    public void set_FOV(float value)
	{
        if (value <= 110 && value >= 60)//validating to make sure that the input given is within the allowed bounds
        {
            CamFOV = Mathf.FloorToInt(value);
        }
	}
    public void set_Sens(float value)
	{
        sens = value;
	}
    public void set_ADS(float value)
	{
        ADSmultiplier = value;
	}
    //SETTERS

    //GETTERS
    public float get_sens()
	{
        return sens;
	}
    public float get_fov()
	{
        return CamFOV;
	}
    public float get_ADS()
	{
        return ADSmultiplier;
	}
    //GETTERS
}
