using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class P2_OPT : MonoBehaviour
{
	[SerializeField] private P2_GSCONTROLLER gridshotClass;
	[SerializeField] private P2_LP linePathClass;

	[SerializeField] private P2_MOUSE mouseClass;
	[SerializeField] private P2_UI UIclass;
		
	[SerializeField] private GameObject optionsMenu;
	[SerializeField] private GameObject mainSettings;
	[SerializeField] private GameObject controlsMenu;
	[SerializeField] private GameObject crosshairMenu;
	[SerializeField] private GameObject preGameCanvas;
	[SerializeField] private Canvas gameUI;
	[SerializeField] private TextMeshProUGUI timerText;

	[SerializeField] private Button controlsButton;
	[SerializeField] private Button crosshairButton;

	[SerializeField] private Button controlsToMainButton;
	[SerializeField] private Button crosshairToMainButton;

	[SerializeField] TextMeshProUGUI sensValueText;
	[SerializeField] TextMeshProUGUI FOVValueText;
	[SerializeField] TextMeshProUGUI ADSValueText;

	[SerializeField] private Slider fovSlider;
	[SerializeField] private Slider sensSlider;
	[SerializeField] private Slider ADSslider;

	[SerializeField] private Slider dotSizeSlider;
	[SerializeField] private Slider centerGapSlider;
	[SerializeField] private Slider lineWidthSlider;
	[SerializeField] private Slider lineHeightSlider;

	[SerializeField] private TMP_InputField fovInputField;
	[SerializeField] private TMP_InputField sensInputField;
	[SerializeField] private TMP_InputField ADSInputFeild;

	[SerializeField] private TMP_InputField dotSizeInputField;
	[SerializeField] private TMP_InputField centerGapInputField;
	[SerializeField] private TMP_InputField lineWidthInputField;
	[SerializeField] private TMP_InputField lineHeightInputField;

	[SerializeField] private TextMeshProUGUI preGameTimerText;

	private bool paused;
	private bool preGame = true;
	private bool preGameTimerBool;
	private float preGameTimer = 3;

	private bool taskEnded;

	private int testint;

	private void Start()
	{
		optionsMenu.SetActive(false);
		gameUI.gameObject.SetActive(false);
		preGameTimerText.text = preGameTimer.ToString();
	}
	private void Update()
	{	
		if(SceneManager.GetActiveScene().buildIndex == 1)
		{
			gridshotClass.set_preGame(preGame);
		}
		else if(SceneManager.GetActiveScene().buildIndex == 2)
		{
			linePathClass.get_preGame();
		}

		//updates the text onscreen to the value its based on every frame
		sensValueText.text = mouseClass.get_sens().ToString();
		FOVValueText.text = mouseClass.get_fov().ToString();
		ADSValueText.text = mouseClass.get_ADS().ToString();
	
		//BUTTONCLICK LISTENERS
		//every time the buttons are clicked          //these methods are run
		controlsButton.onClick.AddListener(delegate { goToControlsFromMain(); });
		crosshairButton.onClick.AddListener(delegate { goToCrosshairFromMain(); });

		controlsToMainButton.onClick.AddListener(delegate { goToMainFromControls(); });
		crosshairToMainButton.onClick.AddListener(delegate { goToMainFromCrosshair(); });
		//BUTTONCLICK LISTENERS

		//SLIDER LISTENERS	
		//when the values of the sliders change, it runs the setters to set the value, with the paramater passed through being the value of the slider
		fovSlider.onValueChanged.AddListener(delegate { mouseClass.set_FOV(value:fovSlider.value); });
		sensSlider.onValueChanged.AddListener(delegate { mouseClass.set_Sens(value: sensSlider.value); });
		ADSslider.onValueChanged.AddListener(delegate { mouseClass.set_ADS(value: ADSslider.value); });

		dotSizeSlider.onValueChanged.AddListener(delegate { UIclass.set_dotSize(value: dotSizeSlider.value); });
		centerGapSlider.onValueChanged.AddListener(delegate { UIclass.set_centerGap(value: centerGapSlider.value); });
		lineWidthSlider.onValueChanged.AddListener(delegate { UIclass.set_lineWidth(value: lineWidthSlider.value); });
		lineHeightSlider.onValueChanged.AddListener(delegate { UIclass.set_lineHeight(value: lineHeightSlider.value); });
		//SLIDER LISTENERS

		//INPUTFIELD LISTENERS
		//when the user submits the inputfield it runs the input methods with the paramater passed through being the text in the inputfield
		fovInputField.onSubmit.AddListener(delegate { FOVInput(value: fovInputField.text); });
		sensInputField.onSubmit.AddListener(delegate { SensInput(value: sensInputField.text); });
		ADSInputFeild.onSubmit.AddListener(delegate { ADSInput(value: ADSInputFeild.text); });

		dotSizeInputField.onSubmit.AddListener(delegate { dotSizeInput(value: dotSizeInputField.text); });
		centerGapInputField.onSubmit.AddListener(delegate { centerGapInput(value: centerGapInputField.text); });
		lineWidthInputField.onSubmit.AddListener(delegate { lineWidthInput(value: lineWidthInputField.text); });
		lineHeightInputField.onSubmit.AddListener(delegate { lineHeightInput(value: lineHeightInputField.text); });
		//INPUTFIELD LISTENERS


		if (SceneManager.GetActiveScene().buildIndex == 1)
		{
			taskEnded = gridshotClass.get_taskEnded();
		}
		else if(SceneManager.GetActiveScene().buildIndex == 2)
		{
			taskEnded = linePathClass.get_taskEnded();
		}

		if (taskEnded)
		{
			//if the task has ended, it makes the gameUI invisible
			gameUI.gameObject.SetActive(false);
			paused = false;
		}

		if (Input.GetKeyDown(KeyCode.Escape))
		{
			//shows the settings page when escape is clicked
			mainSettings.SetActive(true);
		}

		if (paused)
		{
			//activates the optionsMenu if the game is paused
			optionsMenu.SetActive(true);
		}
		else if(!paused && !taskEnded)
		{
			optionsMenu.SetActive(false);
			controlsMenu.SetActive(false);
			crosshairMenu.SetActive(false);

			gameUI.gameObject.SetActive(true);
			timerText.gameObject.SetActive(true);
		}




		//When escape is pressed, it performs the NOT operation on paused
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			if (!taskEnded)
			{
				paused = !paused;
			}
		}


		//performs the actions when the game is in pregame state and the player isnt in the options menu
		if (preGame && !paused)
		{	
			if (Input.GetMouseButtonDown(0))
			{
				preGameTimerBool = true;
			}

			//starts the pregametimer countdown when true
			if (preGameTimerBool)
			{
				preGameTimer -= Time.deltaTime;
				preGameTimerText.text = preGameTimer.ToString();
			}

			//when the pregametimer reaches 0 or below
			if (preGameTimer <= 0)
			{
				//sets pregame to false to start the game
				preGame = false;
				gameUI.gameObject.SetActive(true);
				preGameCanvas.SetActive(false);
			}
		}
	}
	//these methods run when the input field is submitted
	public void FOVInput(string value)//takes in a string parameter
	{
		//if there is only integers in the string passed through, pass it into the temp value
		if (int.TryParse(value, out int tempval))
		{
			//if the tryparse returns true, use the setFOV method on the temp value
			mouseClass.set_FOV(tempval);
		}
	}
	public void SensInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			mouseClass.set_Sens(tempval);
		}
	}
	public void ADSInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			mouseClass.set_ADS(tempval);
		}
	}
	public void centerGapInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			UIclass.set_centerGap(tempval);
		}
	}
	public void dotSizeInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			UIclass.set_dotSize(tempval);
		}
	}
	public void lineWidthInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			UIclass.set_lineWidth(tempval);
		}
	}
	public void lineHeightInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			UIclass.set_lineHeight(tempval);
		}
	}

	public void gunVolumeInput(string value)
	{
		if (int.TryParse(value, out int tempval))
		{
			
		}
	}
	//GO TO MAIN
	//These methods run when the buttons are clicked and they control which options screens to show
	private void goToMainFromControls()
	{
		controlsMenu.SetActive(false);
		mainSettings.SetActive(true);
	}

	private void goToMainFromCrosshair()
	{
		crosshairMenu.SetActive(false);
		mainSettings.SetActive(true);
		gameUI.gameObject.SetActive(false);
		timerText.gameObject.SetActive(true);
	}
	//GO TO MAIN

	//GO TO SUBSETTINGS
	private void goToControlsFromMain()
	{
		mainSettings.SetActive(false);
		controlsMenu.SetActive(true);
	}


	private void goToCrosshairFromMain()
	{
		mainSettings.SetActive(false);
		crosshairMenu.SetActive(true);
		gameUI.gameObject.SetActive(true);
		timerText.gameObject.SetActive(false);
	}
	//GO TO SUBSETTINGS

	//GETTERS
	public bool get_paused()
	{
		return paused;
	}
	public bool get_preGame()
	{
		return preGame;
	}
	//GETTERS
}

