    using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LinepathTest : MonoBehaviour
{
    [SerializeField] private Material pavement;
    private float damage = 10f;
    private float range = 100f;

    [SerializeField] private Camera camera;
    [SerializeField] private GameObject gun;
    [SerializeField] private GameObject spawncube;


    //Stats vars
    private Vector3 shotPosition;
    private float errorSize;


    private float shotsTotal;
    private float targetsHit;

    private float accuracy;
    //end stats vars

    //targetspawner vars
    private float randy;
    private float randx;
    private float randz;

    private float minx;
    private float maxx;
    private float miny;
    private float maxy;
    private float minz;
    private float maxz;

    private int TotalTargetsSpawned = 0; //Used to be TotalTargets
    private int MaxTargetsSpawned = 1; //Used to be TargetCount

    [SerializeField] private GameObject Target;
    [SerializeField] private GameObject tspawn;

    private Vector3 SpawnPosition; //Used to be spawnpos
    private Vector3 center;

    private BoxCollider col;


    private GameObject[] TargetArray;

    //end targetspawner vars

    //linepath vars
    private Vector3[] points;
    private GameObject[] linesegments;
    private float linewidth = 0.3f;
    private float totalTime;
    private float hoverTime;
    //end linepath vars

    //Graph vars
    //private float[,] AccuracyList;
    //private int positionT;
    //private int positionA;
    private Vector2[] graphPoints;
    private GameObject[] graphObjects;
    private GameObject[] graphLines;
    private int xValue;
    private int t2;
    private float t;
    [SerializeField] private Camera graphCamera;
    //End Graph vars



    [SerializeField] private LayerMask Player;

    
    
    


    private void Start()
    {
        col = spawncube.GetComponent<BoxCollider>();
        //calculates the minimum and maximum values for the x y z spawnpositions
        center = col.center + spawncube.transform.position;

        //calculating minimum and maximum values of x
        minx = center.x - col.size.x / 2f;
        maxx = center.x + col.size.x / 2f;

        //calculating minimum and maximum values of y
        miny = center.y - col.size.y / 2f;
        maxy = center.y + col.size.y / 2f;

        //calculating minimum and maximum values of z
        minz = center.z - col.size.z / 2f;
        maxz = center.z + col.size.z / 2f;

        Application.targetFrameRate = 100;

        TargetArray = new GameObject[MaxTargetsSpawned + 1];
        //Makes an array to store the positions of the targets that have spawned
        points = new Vector3[MaxTargetsSpawned + 1];
        //Makes an array to store the cube game objects that have been generated
        linesegments = new GameObject[TargetArray.Length - 1];

        graphPoints = new Vector2[5];

        graphObjects = new GameObject[graphPoints.Length];

        graphLines = new GameObject[graphPoints.Length - 1];

       
        



        for (int i = 0; i < graphPoints.Length; i++)
		{
            graphPoints[i].x = xValue;
            xValue += 15;
		}

        graphCamera.enabled = false;
		
	}
	void Update()
    {
        t += Time.deltaTime;
        

        //when left click is clicked it calls the shoot() function and increments shotsTotal by 1
        if (Input.GetButtonDown("Fire1"))
        {
            shoot();
        }

        while (TotalTargetsSpawned < MaxTargetsSpawned)
        {
            //Generates random values for x and y spawn coordinates
            randy = Random.Range(miny, maxy);
            randx = Random.Range(minx, maxx);
            //applies the randomly generated numbers to the spawnpositon vector to use to spawn the targets
            SpawnPosition.y = randy;
            SpawnPosition.x = randx;
            SpawnPosition.z = center.z;

            //Creates a sphere and adds to targetArray
            TargetArray[TotalTargetsSpawned] = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            //Changes the position of the spawned target to the spawnposition generated above
            TargetArray[TotalTargetsSpawned].transform.position = SpawnPosition;
            //Changes the scale to size it by 1.5x
            TargetArray[TotalTargetsSpawned].transform.localScale =new Vector3(1.5f, 1.5f, 1.5f);
            //Adds the target script so it can be destroyed when shot
            TargetArray[TotalTargetsSpawned].AddComponent<LPTS>();

            //Sets the index 1 of points to be the position of the currently spawned in target to generate a line to its position
            points[1] = SpawnPosition;
            
            //Increments TotalTargetsSpawned by 1 for the counter controlled loop
            TotalTargetsSpawned += 1;

            if (targetsHit > 0)
            {
                generateLines();
               
            }

        }

        //Debug.Log(Mathf.FloorToInt(t));
        //GraphTest

        if (Mathf.FloorToInt(t) > 0)
		{
            t = Mathf.Round(t * 100) / 100;
            
            if (t % 2 == 0)
            {
                if(t2 < graphPoints.Length)
				{
                    
                    graphPoints[t2].y = accuracy;
                    
                    
                    t2 += 1;

                    
                    
                }
                
            }
        }
    }
    private void shoot()
    {
        shotsTotal += 1;
        RaycastHit ShotHit;

        //Returns true if the raycast hits an object
        if (Physics.Raycast(camera.transform.position, camera.transform.forward, out ShotHit, range, ~Player))
        {
            //Checks the GameObject that has been hit to see if it has a "Target" Script on it
            LPTS target = ShotHit.transform.GetComponent<LPTS>();

            //If the GameObject does have a target script on it, cause the target to take damage
            if (target != null)
            {
                
                if (targetsHit > 0)
                {
                   // totalTime += linesegments[0].GetComponent<Colourchanger>().totalTime;
                   // hoverTime += linesegments[0].GetComponent<Colourchanger>().hoverTime;
                }
                
                target.takedamage(damage);
                targetsHit += 1;
                //Decrements TotalTargetsSpawned by 1 in order to spawn another target in since this one got destroyed
                TotalTargetsSpawned -= 1;

                //Calculates errorsize by getting the x and y distance from the shot positon to the center fot the target then adds it to
                //the errorsize variable then divides it by the number of targets hit to get the average errorsize
                shotPosition = ShotHit.point;
                errorSize += shotPosition.x - ShotHit.transform.position.x;
                errorSize += shotPosition.y - ShotHit.transform.position.y;
                errorSize /= targetsHit;

                //Calculating Accuracy
                accuracy = (targetsHit / shotsTotal) * 100;

                

                Debug.Log(accuracy);
                

                

                //Destroys the previous line before changing the index of the new line
                GameObject.Destroy(linesegments[0]);


                //Sets the 0 index of the points array to the position of where the player shot so that the line can generate between that
                //and the new target that spawns in
                points[0] = shotPosition;

                

                
            }
        }
        return;
    }
    private void generateLines()
    {
        for (int i = 0; i < TargetArray.Length - 1; i++)
        {
            //Creates a primitive cube object
            linesegments[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            //Adds the "Colourchanger" script onto the created object
            linesegments[i].AddComponent<Colourchanger>();
            //Sets the position of the cube to be in between the position of the current and next index in the array
            linesegments[i].transform.position = (points[i]+ points[i + 1]) / 2;
            //Changes the length to be the equal to the distance between the 2 points
            linesegments[i].transform.localScale = new Vector3(linewidth, Vector2.Distance(points[i], points[i + 1]), linewidth);
            //Changes the rotation from the default rotation to rotate towards the position of the next point in the array
            linesegments[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, points[i + 1] - points[i]);
        }
    }

    private void generateGraphPoints()
	{   
        for (int i = 0; i < graphPoints.Length; i++)
        {
            graphObjects[i] = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            graphObjects[i].transform.position = graphPoints[i];
        }
	}

    private void generateGraphLines()
	{
        for (int i = 0; i < graphPoints.Length - 1; i++)
        {
            graphLines[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            graphLines[i].transform.position = (graphPoints[i] + graphPoints[i + 1]) / 2;
            graphLines[i].transform.localScale = new Vector3(linewidth, Vector2.Distance(graphPoints[i], graphPoints[i + 1]), linewidth);
            graphLines[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, graphPoints[i + 1] - graphPoints[i]);
        }
    }
}
