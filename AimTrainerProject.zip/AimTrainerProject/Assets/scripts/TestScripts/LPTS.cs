using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LPTS : MonoBehaviour
{
	private float health = 10f;

	public void takedamage(float amount)
	{
		health -= amount;
		if (health <= 0)
		{
			Die();
		}

		void Die()
		{
			Destroy(gameObject);
		}


	}
}
