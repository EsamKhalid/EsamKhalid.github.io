using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gtest2 : MonoBehaviour
{
    [SerializeField] private Vector2[] points;
    private GameObject[] linesegments;
    private GameObject[] l2;
    [SerializeField] private Material linematerial;
    private float linewidth = 0.5f;
    // Start is called before the first frame update
    void Start()
    {

        linesegments = new GameObject[points.Length];//points.Length - 1];

        l2 = new GameObject[points.Length - 1];
        for (int i = 0; i < points.Length; i++)
		{
            linesegments[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            linesegments[i].GetComponent<Renderer>().material = linematerial;
            linesegments[i].transform.position = points[i];
		} 
        for (int i = 0; i < points.Length - 1; i++)
		{
            l2[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            l2[i].transform.position = (points[i] + points[i + 1]) / 2;
            l2[i].transform.localScale = new Vector3(linewidth, Vector2.Distance(points[i], points[i + 1]), linewidth);
            l2[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, points[i + 1] - points[i]);
            
       
            
		}
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
