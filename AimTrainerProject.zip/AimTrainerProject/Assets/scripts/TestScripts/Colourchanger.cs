using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Colourchanger : MonoBehaviour
{

	private Color defaultColor;
	private float totalTime;
	private float hoverTime;
	private bool counting;
	                              
	private void Start()
	{
		//Sets the default colour to the colour that the object spawns in with
		defaultColor = gameObject.GetComponent<Renderer>().material.color;
	}
	private void Update()
	{	
		//adds time to hovertime every frame
		totalTime += Time.deltaTime;

		//if the player is hovering over the line
		if (counting)
		{
			//adds to hovertime every frame
			hoverTime += Time.deltaTime;
		}
	}
	private void OnMouseEnter()
	{	
		//when hovering over the object, it changes the colour to green
		gameObject.GetComponent<Renderer>().material.color = Color.green;
		counting = true;
		
	}

	private void OnMouseExit()
	{
		//When no longer hovering over the object, it changes the colour back to the default colour
		gameObject.GetComponent<Renderer>().material.color = defaultColor;
		counting = false;
	}

	public float get_hoverTime()
	{
		return hoverTime;
	}
	public float get_totalTime()
	{
		return totalTime;
	}
}
