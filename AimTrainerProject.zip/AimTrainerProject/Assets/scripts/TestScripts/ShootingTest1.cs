using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShootingTest1 : MonoBehaviour
{
    private float damage = 10f;
    private float range = 100f;

    [SerializeField] private Camera camera;
    [SerializeField] private GameObject gun;
    [SerializeField] private GameObject spawncube;
    



	
    //Stats vars
	private Vector3 shotPosition;
    private float errorSize;


    private int shotsTotal;
    private int targetsHit;

    private float accuracy;
    //end stats vars

    //targetspawner vars
    private float randy;
    private float randx;
    private float randz;

    private float minx;
    private float maxx;
    private float miny;
    private float maxy;
    private float minz;
    private float maxz;

    private int TotalTargetsSpawned = 0; //Used to be TotalTargets
    private int MaxTargetsSpawned = 3; //Used to be TargetCount

    [SerializeField] private GameObject Target;
    [SerializeField] private GameObject tspawn;

    private Vector3 SpawnPosition; //Used to be spawnpos
    private Vector3 center;

    [SerializeField] BoxCollider col;
    //end targetspawner vars

    //linepath vars

    private Vector2[] points;
    private GameObject[] linesegments;
    private GameObject[] l2;
    [SerializeField] private Material linematerial;
    private float linewidth = 0.5f;
    //end linepath vars



    [SerializeField] private LayerMask Player;




    private void Start()
    {
        //calculates the minimum and maximum values for the x y z spawnpositions
        center = col.center + spawncube.transform.position;

        //calculating minimum and maximum values of x
        minx = center.x - col.size.x / 2f;
        maxx = center.x + col.size.x / 2f;

        //calculating minimum and maximum values of y
        miny = center.y - col.size.y / 2f;
        maxy = center.y + col.size.y / 2f;

        //calculating minimum and maximum values of z
        minz = center.z - col.size.z / 2f;
        maxz = center.z + col.size.z / 2f;


        Application.targetFrameRate = 100;
        

    }



   
    void Update()
    {
        
        GameObject clone;
        
        //when left click is clicked it calls the shoot() function and increments shotsTotal by 1
        if (Input.GetButtonDown("Fire1"))
        {
            shoot();
            
           
        }

        while (TotalTargetsSpawned  < MaxTargetsSpawned)//rohannnn:)
        {   
            //Generates random values for x and y spawn coordinates
            randy = Random.Range(miny, maxy);
            randx = Random.Range(minx, maxx);
            //applies the randomly generated numbers to the spawnpositon vector to use to spawn the targets
            SpawnPosition.y = randy;
            SpawnPosition.x = randx;
            SpawnPosition.z = center.z;

            points[TotalTargetsSpawned] = SpawnPosition;
            
                
            //Creates clones of the targets using the randomly generated spawnpositon
            clone = Instantiate(Target, SpawnPosition, tspawn.transform.rotation);

            clone.tag = "target";

            //Increments TotalTargetsSpawned by 1 for the counter controlled loop
            TotalTargetsSpawned += 1;

        }

        Debug.Log(points);


    }

    void shoot()
    {
        shotsTotal += 1;
        RaycastHit ShotHit;

        //Returns true if the raycast hits an object
        if (Physics.Raycast(camera.transform.position, camera.transform.forward, out ShotHit, range, ~Player))
        {
            //Checks the GameObject that has been hit to see if it has a "Target" Script on it
            TargetScript target = ShotHit.transform.GetComponent<TargetScript>();

            Debug.Log(ShotHit.transform.name);


            //If the GameObject does have a target script on it, cause the target to take damage
            if (target != null)
            {
                target.takedamage(damage);
                //Decrements TotalTargetsSpawned by 1 in order to spawn another target in since this one got destroyed
                TotalTargetsSpawned -= 1;

                //Calculates errorsize by getting the x and y distance from the shot positon to the center fot the target then adds it to
                //the errorsize variable then divides it by the number of targets hit to get the average errorsize
                shotPosition = ShotHit.point;
                errorSize += shotPosition.x - ShotHit.transform.position.x;
                errorSize += shotPosition.y - ShotHit.transform.position.y;
                errorSize /= targetsHit;
               
                targetsHit += 1;

                //Calculating Accuracy
                accuracy = (targetsHit / shotsTotal) * 100;
                
            }

        }

    }


    void generateLines()
	{

	}
}
