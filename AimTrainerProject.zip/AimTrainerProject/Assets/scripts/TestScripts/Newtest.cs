using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Newtest : MonoBehaviour
{
    private RectTransform Container;
    [SerializeField] private Sprite Circle;
    private Vector2 rectSize = new Vector2(11, 11);
    private Vector2 rectmin = new Vector2(0, 0);
    private Vector2 rectmax = new Vector2(0, 0);

    // Start is called before the first frame update
    void Start()
    {
        Container = transform.Find("Container").GetComponent<RectTransform>();
        createCircle(new Vector2(100, 100));
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void createCircle(Vector2 anchoredPosition)
	{
        GameObject gameObject = new GameObject("Circle", typeof(Image));
        gameObject.transform.SetParent(Container, false);
        gameObject.GetComponent<Image>().sprite = Circle;
        RectTransform rectTransform = gameObject.GetComponent<RectTransform>();
        rectTransform.anchoredPosition = anchoredPosition;
        rectTransform.sizeDelta = rectSize;
        rectTransform.anchorMin = rectmin;
        rectTransform.anchorMax = rectmax;

    }
}
