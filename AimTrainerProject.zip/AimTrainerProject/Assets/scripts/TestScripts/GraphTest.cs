using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GraphTest : MonoBehaviour
{   
    // The data points for the line graph
    public Vector2[] points;
    private Vector2 rand;
    // The material to use for the line segments
    public Material lineMaterial;

    // The width of the line segments
    public float lineWidth = 0.1f;

    // The GameObjects used to represent the line segments
    private GameObject[] lineSegments;

    // Use this for initialization
    void Start()
    {
        // Create the line segments
        lineSegments = new GameObject[points.Length - 1];
        for (int i = 0; i < points.Length - 1; i++)
        {
            lineSegments[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            lineSegments[i].GetComponent<Renderer>().material = lineMaterial;
            lineSegments[i].transform.localScale = new Vector3(lineWidth, Vector2.Distance(points[i], points[i + 1]), lineWidth);
            //Adds position of current and next point in list then divides by 2 to get the midpoint between them
            lineSegments[i].transform.position = (points[i] + points[i + 1]) / 2;
            lineSegments[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, points[i + 1] - points[i]);
        }
    }

    // Update is called once per frame
    void Update()
    {
        // Update the position and rotation of the line segments
        for (int i = 0; i < points.Length - 1; i++)
        {  
            lineSegments[i].transform.localScale = new Vector3(lineWidth, Vector2.Distance(points[i], points[i + 1]), lineWidth);
            lineSegments[i].transform.position = (points[i] + points[i + 1]) / 2;
            lineSegments[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, points[i + 1] - points[i]);
        }
    }
}

