using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WindowGraph : MonoBehaviour
{
    private RectTransform graphContainer;
    [SerializeField] private Sprite circleSprite;
	private List<Vector2> Lpos = new List<Vector2>();
	private int rand;

	private void Awake()
	{
        graphContainer = transform.Find("GraphContainer").GetComponent<RectTransform>();
		List<int> valuelist = new List<int>() { 65, 98, 56, 45, 30, 22, 17, 15, 13, 17, 25, 37, 40, 36, 33 };

	
		showgraph(valuelist);
	}

	private void CreateCircle(Vector2 anchoredPosition)
	{
		GameObject gameObject = new GameObject("circle", typeof(Image));
		gameObject.transform.SetParent(graphContainer, false);
		gameObject.GetComponent<Image>().sprite = circleSprite;
		RectTransform rectTransform = gameObject.GetComponent<RectTransform>();
		rectTransform.anchoredPosition = anchoredPosition;
		rectTransform.sizeDelta = new Vector2(11, 11);
		rectTransform.anchorMin = new Vector2(0, 0);
		rectTransform.anchorMax = new Vector2(0, 0);
	}
	private void showgraph(List<int> valuelist)
	{
		float grapheight = graphContainer.sizeDelta.y;
		float maxy = Mathf.Max(valuelist.ToArray());
		float xsize = 50f;
		for(int i = 0; i < valuelist.Count; i ++)
		{
			float xposition = xsize + i * xsize;	
			float yposiion = (valuelist[i] / maxy) * grapheight;
			CreateCircle(new Vector2(xposition, yposiion));
		}
	}

	private void Update()
	{
		
	}

	private void Start()
	{
		string result = "list: ";
		foreach(var x in Lpos)
		{
			result += x.ToString() + ", ";
		}
		//Debug.Log(result);
	}
}
