using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Gridshot : MonoBehaviour
{
 
    private float damage = 10f;
    private float range = 100f;

    
    [SerializeField] private GameObject gun;
    [SerializeField] private GameObject spawncube;
    [SerializeField] private GameObject playerCharacter;

    //PreGame vars
    [SerializeField] private GameObject preGameScreen;
    [SerializeField] private GameObject preGameCTS;
    [SerializeField] private TextMeshProUGUI preGameTimerText;
    private bool preGame;
    private bool preGameCountDown;
    private float preGameTimer = 4f;
    private bool paused2;
    //End Pregame vars

    //UI vars
    [SerializeField] private Camera playerCamera;
    [SerializeField] private AudioSource gunShot;
    [SerializeField] private GameObject controlsMenu;
    [SerializeField] private GameObject audioMenu;
    [SerializeField] private TextMeshProUGUI gunVolumeText;
    [SerializeField] private GameObject mainSettings;
    [SerializeField] private GameObject gameUI;
    [SerializeField] private TextMeshProUGUI timerText;
    private Vector3 mousePos;
    private bool paused;
    private bool taskEnded;
    //End UI vars

    //Stats vars
    private Vector3 shotPosition;
    private float errorSize;


    private float shotsTotal;
    private float targetsHit;

    private float accuracy;

    private float totalScore;
    //end stats vars

    //targetspawner vars
    private float randy;
    private float randx;
    private float randz;

    private float minx;
    private float maxx;
    private float miny;
    private float maxy;
    private float minz;
    private float maxz;

    private int TotalTargetsSpawned = 0; //Used to be TotalTargets
    private int MaxTargetsSpawned = 3; //Used to be TargetCount


    private Vector3 SpawnPosition; //Used to be spawnpos
    private Vector3 center;

    private BoxCollider col;


    private GameObject[,] targetSpawnPoints;

    //end targetspawner vars


    private float linewidth = 1f;

    //Graph vars
    private Vector2[] graphPoints;
    private GameObject[] graphObjects;
    private GameObject[] graphLines;
    private float xValue;
    private int t2;
    private float t;
    [SerializeField] private Camera graphCamera;
    private float TaskTime = 10f;
    private float timerCounter;
    private int graphPointsDistance;
    //End Graph vars

    //Gridshot vars
    [SerializeField] private GameObject spawn1;
    [SerializeField] private GameObject spawn2;
    [SerializeField] private GameObject spawn3;
    [SerializeField] private GameObject spawn4;
    [SerializeField] private GameObject spawn5;
    [SerializeField] private GameObject spawn6;
    [SerializeField] private GameObject spawn7;
    [SerializeField] private GameObject spawn8;
    [SerializeField] private GameObject spawn9;
    private Vector3 startspawn;
    private List<GameObject> targetList = new List<GameObject>();
    private int randomIndex;
    private List<Vector3> Available = new List<Vector3>();
    private List<Vector3> justDestroyed = new List<Vector3>();
    //End Gridshot vars

    //Results vars
    [SerializeField] private GameObject resultsCanvas;
    [SerializeField] private GameObject graphCanvas;
    [SerializeField] private TextMeshProUGUI accuracyText;
    [SerializeField] private TextMeshProUGUI errorSizeText;
    [SerializeField] private TextMeshProUGUI shotsTotalText;
    [SerializeField] private TextMeshProUGUI targetsHitText;
    [SerializeField] private TextMeshProUGUI reactionTimeText;
    private float reactionTime;
	//End Results vars

	[SerializeField] private LayerMask Player;
    private void Start()
    {   
        graphCanvas.SetActive(false);
        resultsCanvas.SetActive(false);
        preGameScreen.SetActive(true);
        preGameCTS.SetActive(true);
        preGame = true;
        preGameCountDown = false;
        gameUI.SetActive(false);
        paused = true;
        taskEnded = false;
        gunShot.volume = 0f;

        col = spawncube.GetComponent<BoxCollider>();
        //calculates the minimum and maximum values for the x y z spawnpositions
        center = col.center + spawncube.transform.position;

        //calculating minimum and maximum values of x
        minx = center.x - col.size.x / 2f;
        maxx = center.x + col.size.x / 2f;

        //calculating minimum and maximum values of y
        miny = center.y - col.size.y / 2f;
        maxy = center.y + col.size.y / 2f;

        //calculating minimum and maximum values of z
        minz = center.z - col.size.z / 2f;
        maxz = center.z + col.size.z / 2f;

        Application.targetFrameRate = 100;
       
    //Array to store the position of where the graph points will spawn.
    //Makes the length the same as the TaskTime to get a position value for every second of the task
    graphPoints = new Vector2[Mathf.FloorToInt(TaskTime)];


    //Array to store the spawned in graph points
    graphObjects = new GameObject[graphPoints.Length];

    //Array to store the lines that are made between the graph points
    graphLines = new GameObject[graphPoints.Length - 1];

        Available.Add(spawn1.transform.position);
        Available.Add(spawn2.transform.position);
        Available.Add(spawn3.transform.position);
        Available.Add(spawn4.transform.position);
        Available.Add(spawn5.transform.position);
        Available.Add(spawn6.transform.position);
        Available.Add(spawn7.transform.position);
        Available.Add(spawn8.transform.position);
        Available.Add(spawn9.transform.position);



        graphPointsDistance = 180 / graphPoints.Length;
        ////Adds the minutes to the list of values

        for (int i = 0; i < graphPoints.Length; i++)
		{
			graphPoints[i].x = xValue;
			xValue += graphPointsDistance;
		}

		graphCamera.enabled = false;

        
    }
    void Update()
    {

		if (Input.GetKeyDown(KeyCode.Escape))
		{
			if (preGame == false)
			{
                paused = !paused;
            }
            paused2 = !paused2;
            
		}

		if (!paused)
		{
            TaskTime -= Time.deltaTime;
            t += Time.time;
        }

		if (paused)
		{   
            gunVolumeText.text = (Mathf.Round(gunShot.volume * 100).ToString() + "%");
            gameUI.SetActive(false);
        }





        
        timerText.text = "[" + Mathf.FloorToInt(TaskTime).ToString() + "]";
        


        //when left click is clicked it calls the shoot() function and increments shotsTotal by 1
        if (Input.GetButtonDown("Fire1"))
        {
			if (!preGame && !paused)
			{
                shoot();
            }
            
          
			if(preGameTimer >= 0 && !paused2)
			{
                preGameCountDown = true;
                preGameCTS.SetActive(false);
			}

        }
        if (preGameTimer >= 0 && preGameCountDown == true)
        {
            preGameTimerText.text = "[" + Mathf.FloorToInt(preGameTimer).ToString() + "]";
        }
        
        if (preGameTimer <= 0)
        {
            preGameScreen.SetActive(false);
            preGame = false;
            paused = false;
			if (!taskEnded)
			{
                gameUI.SetActive(true);
            }
            
        }

    
		if (preGameCountDown)
		{
            preGameTimer -= Time.deltaTime;
        }

        while (TotalTargetsSpawned < MaxTargetsSpawned)
        {

            if(targetsHit > 1)
			{
                Available.Add(justDestroyed[0]);
                justDestroyed.Remove(justDestroyed[0]);
			}
            randomIndex = Random.Range(0, Available.Count);
            
            targetList.Add(GameObject.CreatePrimitive(PrimitiveType.Sphere));
            targetList[TotalTargetsSpawned].transform.position = Available[randomIndex];
            targetList[TotalTargetsSpawned].transform.localScale = new Vector3(4.5f, 4.5f, 4.5f);
            targetList[TotalTargetsSpawned].AddComponent<TargetScript>();
            targetList[TotalTargetsSpawned].GetComponent<Renderer>().material.color = Color.black;
            Available.Remove(targetList[TotalTargetsSpawned].transform.position);

            //Increments TotalTargetsSpawned by 1 for the counter controlled loop
            TotalTargetsSpawned += 1;
        }
		

        if (Time.time > timerCounter)
        {
            if (paused == false || preGame == false)
            {
                if (t2 < graphPoints.Length)
                {
                    //accuracy = targetsHit / shotsTotal;
                    //errorSize /= targetsHit;
                    //reactionTime = t2 / targetsHit;
                    //totalScore = accuracy * Mathf.Abs(errorSize) * (reactionTime * 1000);
                    //graphPoints[t2].y = totalScore / 10;
                    //reactionTime = t2 / targetsHit;
                    //graphPoints[t2].y = reactionTime * 100;
                    graphPoints[t2].y = accuracy;
                    //graphPoints[t2].y = Mathf.FloorToInt(t); //FOR TESTING GRAPH FUNCTIONALITY
                    t2 += 1;
                }
            }
            

            timerCounter += 1;//The value here(1) controls the time interval between each iteration (2 means every 2 seconds, 3 means every 3 seconds etc.)
        }

        if (Mathf.Round(TaskTime * 100) / 100 == 0)
        {
            resultsCanvas.SetActive(true);
            //Generates the graph point objects and draws lines between them
            generateGraphPoints();
            generateGraphLines();
            graphCamera.enabled = true;

            Destroy(playerCamera.GetComponent<MouseLook>());
            Destroy(playerCharacter.GetComponent<PlayerMovement>());
            playerCamera.enabled = false;
            //Deactivates the gameUI so it doesnt block the graph and results
            gameUI.SetActive(false);
            //Unlocks the mouse and makes it visible
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            taskEnded = true;
            reactionTime = (graphPoints.Length / targetsHit) * 1000;
            reactionTime = (Mathf.Round((graphPoints.Length / targetsHit) * 1000));
            errorSize /= targetsHit;
            accuracyText.text ="Accuracy = "  + "[" + Mathf.Round(accuracy * 100) / 100 + "]";
            errorSizeText.text = "ErrorSize = " + "[" + Mathf.Round(errorSize * 100) / 100 + "]";
            shotsTotalText.text = "ShotsTotal = " + "[" + shotsTotal + "]";
            targetsHitText.text = "targetsHit = " + "[" + targetsHit + "]";
            reactionTimeText.text = "reactionTime = " + "[" + reactionTime + " ms" + "]";
        }
    }
    private void shoot()
    {
        gunShot.Play();
        shotsTotal += 1;
        RaycastHit ShotHit;

        //Returns true if the raycast hits an object
        if (Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward, out ShotHit, range, ~Player))
        {
            //Checks the GameObject that has been hit to see if it has a "Target" Script on it
            TargetScript target = ShotHit.transform.GetComponent<TargetScript>();

            //If the GameObject does have a target script on it, cause the target to take damage
            if (target != null)
            {

                justDestroyed.Add(ShotHit.transform.position);
                targetList.Remove(ShotHit.transform.gameObject);

                target.takedamage(damage);
                targetsHit += 1;
                //Decrements TotalTargetsSpawned by 1 in order to spawn another target in since this one got destroyed
                TotalTargetsSpawned -= 1;

                //Calculates errorsize by getting the x and y distance from the shot positon to the center fot the target then adds it to
                //the errorsize variable then divides it by the number of targets hit to get the average errorsize
                shotPosition = ShotHit.point;
                errorSize += shotPosition.x - ShotHit.transform.position.x;
                errorSize += shotPosition.y - ShotHit.transform.position.y;

                

                //Calculating Accuracy
                accuracy = (targetsHit / shotsTotal) * 100;


            }
        }

    }
    private void generateGraphPoints()
    {
        for (int i = 0; i < graphPoints.Length; i++)
        {
            graphObjects[i] = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            graphObjects[i].transform.position = graphPoints[i];
            graphObjects[i].transform.localScale = new Vector3(3f, 3f, 3f);

            //graphObjects[i].AddComponent<graphPointHover>();

        }
    }
    private void generateGraphLines()
    {
        for (int i = 0; i < graphPoints.Length - 1; i++)
        {
            graphLines[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            graphLines[i].transform.position = (graphPoints[i] + graphPoints[i + 1]) / 2;
            graphLines[i].transform.localScale = new Vector3(linewidth, Vector2.Distance(graphPoints[i], graphPoints[i + 1]), linewidth);
            graphLines[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, graphPoints[i + 1] - graphPoints[i]);
        }
    }
    public void goToMainFromAudio()
	{
        audioMenu.SetActive(false);
        mainSettings.SetActive(true);
	}
    public void changeGunvolume(float value)
	{
        gunShot.volume = value;

    }

    public void viewGraph()
	{
        resultsCanvas.SetActive(false);
        graphCanvas.SetActive(true);
	}

   public void backToResults()
	{
        resultsCanvas.SetActive(true);
        graphCanvas.SetActive(false);
	}
}
