using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class gridshotNeat : MonoBehaviour
{

    private List<targetData> targetDataList = new List<targetData>();

    private float counter;
    private float counter2;

    private float damage = 10f;
    private float range = 100f;

    Scene currentScene;


    [SerializeField] private GameObject gun;
    [SerializeField] private GameObject playerCharacter;

    //PreGame vars
    [SerializeField] private GameObject preGameScreen;
    [SerializeField] private GameObject preGameCTS;
    [SerializeField] private TextMeshProUGUI preGameTimerText;
    private bool preGame = true;
    private bool preGameCountDown = false;
    [SerializeField] private float preGameTimer;
    private bool paused2;
    private int temp;
    //End Pregame vars

    //UI vars
    [SerializeField] private GameObject optionsMenu;
    [SerializeField] private Camera playerCamera;
    [SerializeField] private AudioSource gunShot;
    [SerializeField] private GameObject controlsMenu;
    [SerializeField] private GameObject audioMenu;
    [SerializeField] private TextMeshProUGUI gunVolumeText;
    [SerializeField] private GameObject mainSettings;
    [SerializeField] private GameObject gameUI;
    [SerializeField] private TextMeshProUGUI timerText;
    private Vector3 mousePos;
    public static bool paused = true;
    public static bool taskEnded = false;
    //End UI vars

    //Crosshair vars
    [SerializeField] private GameObject crosshairMenu;
    [SerializeField] private TextMeshProUGUI dotSizeText;



    [Range(14, 100)]
    [SerializeField] private float dotSize;


    private string crosshairType;
    

    [SerializeField] private Image dotCrosshair;

    [SerializeField] private RectTransform crosshairRectTransform;
    [SerializeField] private float centerGap;
    [SerializeField] private TextMeshProUGUI centerGapValueText;

    [SerializeField] private RectTransform topLine;
    [SerializeField] private RectTransform bottomLine;
    [SerializeField] private RectTransform leftLine;
    [SerializeField] private RectTransform rightLine;
    [SerializeField] private float lineWidth;
    [SerializeField] private float lineHeight;

    //End Crosshair vars

    //Stats vars
    private Vector3 shotPosition;
    private float errorSize;


    private float shotsTotal;
    private float targetsHit;

    private float accuracy;

    private float totalScore;

    private float targetsHitInSecond;

    public static float totalReactionTime;


    private List<float> timeList = new List<float>();
    private float tempListVal;

    //end stats vars

    private int TotalTargetsSpawned = 0; //Used to be TotalTargets
    private int MaxTargetsSpawned = 3; //Used to be TargetCount

    

    //Graph vars
    private Vector2[] graphPoints;
    private GameObject[] graphObjects;
    private GameObject[] graphLines;
    private float xValue;
    private int t2;
    private float t;
    [SerializeField] private Camera graphCamera;
    [SerializeField] private float TaskTime;
    private float remainingTaskTime;
    private float timerCounter;
    private int graphPointsDistance;
    private GameObject graphParent;
    private float timeSinceStart;
    private float tempRT;
    private float rt2;
    private float graphLineWidth = 1f;
    //End Graph vars

    //Gridshot vars
    [SerializeField] private GameObject spawn1;
    [SerializeField] private GameObject spawn2;
    [SerializeField] private GameObject spawn3;
    [SerializeField] private GameObject spawn4;
    [SerializeField] private GameObject spawn5;
    [SerializeField] private GameObject spawn6;
    [SerializeField] private GameObject spawn7;
    [SerializeField] private GameObject spawn8;
    [SerializeField] private GameObject spawn9;
    private Vector3 startspawn;
    private List<GameObject> Spawned = new List<GameObject>();
    private int randomIndex;
    private List<Vector3> Available = new List<Vector3>();
    private List<Vector3> justDestroyed = new List<Vector3>();
    //End Gridshot vars

    //Results vars
    [SerializeField] private GameObject resultsCanvas;
    [SerializeField] private GameObject graphCanvas;
    [SerializeField] private TextMeshProUGUI accuracyText;
    [SerializeField] private TextMeshProUGUI errorSizeText;
    [SerializeField] private TextMeshProUGUI shotsTotalText;
    [SerializeField] private TextMeshProUGUI targetsHitText;
    [SerializeField] private TextMeshProUGUI reactionTimeText;
    private float reactionTime;
    //End Results vars

    //Sliders
    [SerializeField] private Slider dotSizeSlider;
    [SerializeField] private Slider centerGapSlider;
    //Sliders

    //Buttons
    [SerializeField] private Button controlsButton;
    //Buttons

    [SerializeField] private LayerMask Player;





    private string s;



    private float time;

	private void Awake()
	{
        graphParent = new GameObject();
        graphParent.transform.name = "graphParent";
        currentScene = SceneManager.GetActiveScene();
    }
	private void Start()
    {
        taskEnded = false;
        dotSizeSlider.value = dotSize;
        

		if (PlayerPrefs.HasKey("Task1Accuracy"))
		{

		}

		if (PlayerPrefs.HasKey("savedDotSize"))
		{
            dotSize = PlayerPrefs.GetFloat("savedDotSize");
            
		}

        if (PlayerPrefs.HasKey("savedCenterGap"))
		{
            centerGap = PlayerPrefs.GetFloat("savedCenterGap");
		}

       
        remainingTaskTime = TaskTime;


        crosshairType = "dot";
        //dotSize = 23.5f;
        //centerGap = 50f;
        lineWidth = 10f;
        lineHeight = 30f;


        graphCanvas.SetActive(false);
        resultsCanvas.SetActive(false);
        preGameScreen.SetActive(true);
        preGameCTS.SetActive(true);

        gunShot.volume = 0f;

        Application.targetFrameRate = 100;

        //Array to store the position of where the graph points will spawn.
        //Makes the length the same as the TaskTime to get a position value for every second of the task
        graphPoints = new Vector2[Mathf.FloorToInt(TaskTime)];


        //Array to store the spawned in graph points
        graphObjects = new GameObject[graphPoints.Length];

        //Array to store the lines that are made between the graph points
        graphLines = new GameObject[graphPoints.Length - 1];


        

        Available.Add(spawn1.transform.position);
        Available.Add(spawn2.transform.position);
        Available.Add(spawn3.transform.position);
        Available.Add(spawn4.transform.position);
        Available.Add(spawn5.transform.position);
        Available.Add(spawn6.transform.position);
        Available.Add(spawn7.transform.position);
        Available.Add(spawn8.transform.position);
        Available.Add(spawn9.transform.position);


        //Divides the desired length of the graph by the number of graph points to make the graph the same size no matter the number of points
        graphPointsDistance = 200 / graphPoints.Length;
        ////Adds the minutes to the list of values

        for (int i = 0; i < graphPoints.Length; i++)
        {   
            graphPoints[i].x = xValue;
            xValue += graphPointsDistance;
        }

        graphCamera.enabled = false;
    }
    void Update()
    {


		if (!paused)
		{
            counter += Time.deltaTime;
		}


        dotSizeSlider.onValueChanged.AddListener(delegate { changeDotSize(dotSizeSlider.value);});
        centerGapSlider.onValueChanged.AddListener(delegate { changeCenterGap(centerGapSlider.value);});



        crosshairRectTransform.sizeDelta = new Vector2(centerGap, centerGap);
        topLine.sizeDelta = new Vector2(lineWidth, lineHeight);
        bottomLine.sizeDelta = new Vector2(lineWidth, lineHeight);
        leftLine.sizeDelta = new Vector2(lineHeight, lineWidth);
        rightLine.sizeDelta = new Vector2(lineHeight, lineWidth);

        if (playerCharacter.transform.position.y <= -20)
		{
            playerCharacter.transform.position = new Vector3(-111f, 2f, -19f);

        }
        
        //make presets that set the crosshair values to specific values like "dot crosshair" "standard crosshair" "crosshair with dot in middle"
        if(crosshairType == "dot")
		{
            dotCrosshair.enabled = true;
            dotCrosshair.rectTransform.sizeDelta = new Vector2(dotSize, dotSize);
            
        }
        else if(crosshairType == "crosshair")
		{
            dotCrosshair.enabled = true;
            dotCrosshair.rectTransform.sizeDelta = new Vector2(dotSize, dotSize);
            
        }
        

        if (Input.GetKeyDown(KeyCode.Escape))
        {   
            if (preGame == false)
            {
                paused = !paused;
            }
            paused2 = !paused2;
        }



        if (!paused)
        {
            time += Time.deltaTime;
            remainingTaskTime -= Time.deltaTime;
            timeSinceStart += Time.deltaTime;
            t += Time.time;
            timerText.text = "[" + (Mathf.Round(remainingTaskTime * 100) / 100).ToString() + "]";
            gameUI.SetActive(true);
			if (preGame)
			{
                preGameScreen.SetActive(true);
			}

        }

        if (paused)
        {   
            //Displaying text values on sliders
            gunVolumeText.text = (Mathf.Round(gunShot.volume * 100).ToString() + "%");
            dotSizeText.text = (Mathf.Round(dotSize * 100) / 100).ToString();
            centerGapValueText.text = centerGap.ToString();

            //Only inactivates the gameUI if the crosshair menu is not open so that you can see the crosshair when making changes
            if (crosshairMenu.activeInHierarchy == false)
			{
                gameUI.SetActive(false);
            }
			else
			{
                gameUI.SetActive(true);
			}

			if (optionsMenu.activeInHierarchy)
			{
                preGameScreen.SetActive(false);
			}
			else
			{
                preGameScreen.SetActive(true);
			}
        }

        //when left click is clicked it calls the shoot() function
        if (Input.GetButtonDown("Fire1"))
        {
            if (!preGame && !paused)
            {
                shoot();
            }


            if (preGameTimer >= 0 && !paused2)
            {
                preGameCountDown = true;
                preGameCTS.SetActive(false);
            }

        }
        if (preGameTimer >= 0 && preGameCountDown == true)
        {
            preGameTimerText.text = "[" + Mathf.FloorToInt(preGameTimer).ToString() + "]";
        }

        if (preGameTimer <= 0)
        {
            preGameScreen.SetActive(false);
            preGame = false;
            preGameCountDown = false;
            //temp is to make sure it executes only once and the other one is to make sure the timer doesnt start if the player is on the options menu
            if(temp == 0 && !optionsMenu.activeInHierarchy)
			{
                paused = false;
                temp += 1;
			}
        }

        if (preGameCountDown)
        {
            preGameTimer -= Time.deltaTime;
        }

        while (TotalTargetsSpawned < MaxTargetsSpawned)
        {
            randomIndex = Random.Range(0, Available.Count);
            spawnTargets(Available[randomIndex]);
        }


        if (time > 1)
        {
  
            generateAccuracyGraphPositions();
            //generateReactionTimeGraphPositions();
            time = 0;//The value here(1) controls the time interval between each iteration (2 means every 2 seconds, 3 means every 3 seconds etc.)
            

        }

        if(t2 >= TaskTime && !taskEnded  )
		{
            accuracy = targetsHit / shotsTotal;
            //reactionTime /= targetDataList.Count;
            reactionTime = TaskTime / targetsHit;
            errorSize /= targetsHit;
            
    

           

            

            

            endTask();
            taskEnded = true;
        }

		if (taskEnded)
		{
			if (Input.GetKeyDown(KeyCode.Space))
			{
                graphParent.SetActive(false);
			}
		}
    }
    private void generateAccuracyGraphPositions()
	{   

        if (paused == false || preGame == false)
        {
            if (t2 < graphPoints.Length)
            {
                graphPoints[t2].y = accuracy;
                t2 += 1;
            }
        }
    }

    private void generateReactionTimeGraphPositions()
	{   
        if (paused == false || preGame == false)
        {
            if (t2 < graphPoints.Length)
            {

                if(targetsHit > 0)
				{
                    graphPoints[t2].y = t2;
                }
				else
				{
                    graphPoints[t2].y = 0;
				}
                

                t2 += 1;
            }
        }
    }
    private void endTask()
	{
        paused = true;
        gameUI.SetActive(false);
        resultsCanvas.SetActive(true);
        //Generates the graph point objects and draws lines between them
        generateGraphPoints();
        generateGraphLines();
        graphCamera.enabled = true;

        //Destroys the player character and camera since the task has ended to stop errors
        Destroy(playerCamera.GetComponent<MouseLook>());
        Destroy(playerCharacter.GetComponent<PlayerMovement>());
        playerCamera.enabled = false;

        //Deactivates the gameUI so it doesnt block the graph and results
        gameUI.SetActive(false);
        //Unlocks the mouse and makes it visible
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
        taskEnded = true;
        accuracyText.text = "Accuracy = " + "[" + (Mathf.Round(accuracy * 100) / 100) * 100 + "%" + "]";
        errorSizeText.text = "ErrorSize = " + "[" + Mathf.Round(errorSize * 100) / 100 + "]";
        shotsTotalText.text = "ShotsTotal = " + "[" + shotsTotal + "]";
        targetsHitText.text = "targetsHit = " + "[" + targetsHit + "]";
        reactionTimeText.text = "reactionTime = " + "[" + reactionTime + " ms" + "]";

        for(int i = 0; i < targetDataList.Count; i++)
		{
            tempRT += targetDataList[i].get_reactionTime();
		}

        tempRT /= targetDataList.Count;
        Debug.Log("counterRT" + (counter2 / targetsHit));

    }
    private void spawnTargets(Vector3 spawnPosition)
	{
        if (targetsHit > 1)
        {
            Available.Add(justDestroyed[0]);
            justDestroyed.Remove(justDestroyed[0]);
        }

        Spawned.Add(GameObject.CreatePrimitive(PrimitiveType.Sphere));
        Spawned[TotalTargetsSpawned].transform.position = Available[randomIndex];
        Spawned[TotalTargetsSpawned].transform.localScale = new Vector3(4.5f, 4.5f, 4.5f);
        Spawned[TotalTargetsSpawned].AddComponent<TargetScript>();
        Spawned[TotalTargetsSpawned].GetComponent<Renderer>().material.color = Color.black;
        Available.Remove(Spawned[TotalTargetsSpawned].transform.position);

        //Increments TotalTargetsSpawned by 1 for the counter controlled loop
        TotalTargetsSpawned += 1;
    }
    private void shoot()
    {   
        

        gunShot.Play();
        shotsTotal += 1;
        RaycastHit ShotHit;

        //Returns true if the raycast hits an object
        if (Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward, out ShotHit, range, ~Player))
        {
            //Checks the GameObject that has been hit to see if it has a "Target" Script on it and makes an instance of the class
            TargetScript target = ShotHit.transform.GetComponent<TargetScript>();

            //If the GameObject does have a target script on it, cause the target to take damage
            if (target != null)
            {



                counter2 += counter;
                counter = 0;




                //creates a new gameobject
                GameObject targetDataObject = new GameObject();
                //adds the targetData script to the game object
                targetDataObject.AddComponent<targetData>();
                //creates an instance of the class
                targetData targetDataClass = targetDataObject.GetComponent<targetData>();
                //uses the setter in the class to set the vaue in the class as the value returned by the getter in the class of the target that you just destroyed
                targetDataClass.set_reactionTime(target.get_spawnedTime());
                //Adds the instantiated class into the list of instantiated classes to access the values later
                targetDataList.Add(targetDataClass);

               
                
               

                //Adds the target that just got destoryed to the destroyed list
                justDestroyed.Add(ShotHit.transform.position);
                //removes the target that got destroued from the currently spawned list
                Spawned.Remove(ShotHit.transform.gameObject);
                //Makes the target take damage based on the gun damage value
                target.takedamage(damage);
                targetsHit += 1;
                //Decrements TotalTargetsSpawned by 1 in order to spawn another target in since this one got destroyed
                TotalTargetsSpawned -= 1;
                //Calculates errorsize by getting the x and y distance from the shot positon to the center fot the target then adds it to
                //the errorsize variable then divides it by the number of targets hit to get the average errorsize
                shotPosition = ShotHit.point;
                errorSize += shotPosition.x - ShotHit.transform.position.x;
                errorSize += shotPosition.y - ShotHit.transform.position.y;
                //Calculating Accuracy
                accuracy = (targetsHit / shotsTotal) * 100;

                //Destroys the targetObject to not clutter up the editor
                Destroy(targetDataObject);
            }
        }

    }
    private void generateGraphPoints()
    {   
        //Loops through the graphObjects array and makes a sphere at each index
        for (int i = 0; i < graphPoints.Length; i++)
        {   
            //creates an empty sphere game object
            graphObjects[i] = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            //Position is = to the position in the graph points at the same index
            graphObjects[i].transform.position = graphPoints[i];
            //sets the scale to be 3x the default on all 3 axis
            graphObjects[i].transform.localScale = new Vector3(3f, 3f, 3f);
            //sets the parent to be the graph parent 
            graphObjects[i].transform.parent = graphParent.transform;
            //adds either the reactionTime hover or accuracyHover depending on the task
            graphObjects[i].AddComponent<graphPointHoverAccuracy>();
            //graphObjects[i].AddComponent<graphPointHoverReactiontime>();
        }
    }
    private void generateGraphLines()
    {
        for (int i = 0; i < graphPoints.Length - 1; i++)
        {   
            //creates an empty cube gameobject
            graphLines[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
            //sets the position to be inbetween 2 graph values
            graphLines[i].transform.position = (graphPoints[i] + graphPoints[i + 1]) / 2;
            //changes the scale to be the length of the distance between the 2 graph values it is generated between
            graphLines[i].transform.localScale = new Vector3(graphLineWidth, Vector2.Distance(graphPoints[i], graphPoints[i + 1]), graphLineWidth);
            //Sets the rotation from the default rotation to the rotation between a point in the graph and the next point in the graph
            graphLines[i].transform.rotation = Quaternion.FromToRotation(Vector3.up, graphPoints[i + 1] - graphPoints[i]);
            //Sets the lines parent to be the graph parent
            graphLines[i].transform.parent = graphParent.transform;
        }
    }
    //AudioMethods
    public void goToMainFromAudio()
    {
        audioMenu.SetActive(false);
        mainSettings.SetActive(true);
    }
    public void changeGunvolume(float value)
    {
        gunShot.volume = value;
    }
    //End AudioMethods

    //ResultsMethods
    public void viewGraph()
    {
        resultsCanvas.SetActive(false);
        graphCanvas.SetActive(true);
    }

    public void backToResults()
    {
        resultsCanvas.SetActive(true);
        graphCanvas.SetActive(false);
    }

    public void restartTask()
	{
        
        SceneManager.LoadScene(sceneBuildIndex: currentScene.buildIndex);
	}

    public void backToMainMenu()
	{
        SceneManager.LoadScene(sceneBuildIndex: 0);
	}
    //End ResultsMethods
    //Crosshair Methods

    public void saveCrosshairSettings()
	{
        PlayerPrefs.SetFloat("savedDotSize", dotSize);
        PlayerPrefs.SetFloat("savedCenterGap", centerGap);
	}
    
    public void goToMainFromCrosshair()
	{
        crosshairMenu.SetActive(false);
        mainSettings.SetActive(true);
        gameUI.SetActive(false);
	}
    
    private void changeDotSize(float value)
	{
        dotSize = value;
	}

    private void changeCenterGap(float value)
	{
        centerGap = value;
	}

    public void changeLineWidth(float value)
	{
        topLine.sizeDelta = new Vector2(value, lineHeight);
        bottomLine.sizeDelta = new Vector2(value, lineHeight);
    }
    public void changeLineHeight(float value)
	{
        topLine.sizeDelta = new Vector2(lineWidth, lineHeight);

	}
    //End Crosshair Methods


    private void SavePreviousTask(int taskNumber)
	{
        PlayerPrefs.SetFloat("task" + taskNumber.ToString() + "Accuracy", accuracy);
	}

    public bool get_paused()
	{
        return paused;
	}
    public bool get_taskEnded()
	{
        return taskEnded;
	}
}
