using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;
public class MouseLook : MonoBehaviour
{
    //Taken from brackeys tutorial on fps character controller https://www.youtube.com/watch?v=_QajrabyTJc
    //Vlaue for how fast the player wants the look sensetivity
    private float sens = 125f;
    private float tempsense;    
    private float ADSmultiplier = 0.75f;
    private bool paused;

    [SerializeField] private TextMeshProUGUI FOVtext;
    [SerializeField] private TextMeshProUGUI sensText;
    [SerializeField] private TextMeshProUGUI ADStext;

    //Transform of the physical player body to rotate the player body along the Y axis to make sure that the player is always moving in the direction they are facing
    [SerializeField] private Transform playerbody;

    //Value of xrotation to allow the camera to rotate along the X axis to look up and down
    private float xrotation = 0f;

    private float CamFOV = 60f;
    private float tempFOV;

    void Start()
    {   //Code runs at the very start to lock the cursor in the middle of the screen
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = true;
        tempsense = sens;
        tempFOV = CamFOV;

    }

    public void ChangeSenseSlider(float value)
    {
        sens = value;
        
    }

    public void ChangeFOVSlider(float value)
	{
        CamFOV = value;

	}
    public void ChangeADSValue(float value)
	{
        ADSmultiplier = value;
	}
   
  
    // Update is called once per frame
    void Update()
    {

        ADStext.text = ADSmultiplier.ToString();
        sensText.text = sens.ToString();
        FOVtext.text = CamFOV.ToString();


        if (!paused)//If not paused
		{
            //Gets the X input and multiplies it by the sens for the speed and Time.deltaTime to make the camera movement frame independant
            float mouseX = Input.GetAxis("Mouse X") * sens * Time.deltaTime;
            //Gets the X input and multiplies it by the sens for the speed and Time.deltaTime to make the camera movement frame independant
            float mouseY = Input.GetAxis("Mouse Y") * sens * Time.deltaTime;

            //Takes x rotation from mouseY because if it was equal, the rotation of the camera would be flipped compared to the Y input since it is rotating around the X axis
            xrotation -= mouseY;

            //Clamps the rotation of the camera around the X axis to make sure that the player cant look too far behind or too far down
            xrotation = Mathf.Clamp(xrotation, -90f, 90f);


            //Rotates the camera using quaternion and euler angles around the X axis to allow the camera to look up and down
            transform.localRotation = Quaternion.Euler(xrotation, 0f, 0f);

            //Applies a rotation transformation on the up vector(y vector) of the playerbody to rotate it around the y axis to look left and right
            playerbody.Rotate(Vector3.up * mouseX);


            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }


        if (Input.GetMouseButtonDown(1))
		{
            CamFOV *= 0.75f;
            sens = sens * ADSmultiplier;
		}

        if (Input.GetMouseButtonUp(1)) // rohannn:)
        {
            CamFOV = tempFOV;
            sens = tempsense;
            
        }

		if (Input.GetKeyDown(KeyCode.Escape))
		{
            paused = !paused;

        }

		if(paused)

		{   //While Paused
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            sensText.text = sens.ToString();
            FOVtext.text = CamFOV.ToString();
            ADStext.text = ADSmultiplier.ToString();
		}
		
        //changes the main camera's FOV every frame to update it when it changes
        Camera.main.fieldOfView = CamFOV;

        
    }

    
}
