using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private bool paused;

    //Taken from brackeys tutorial on fps character controller https://www.youtube.com/watch?v=_QajrabyTJc
    //allows the referencing of the character controller in the code
    [SerializeField] private CharacterController controller;

    //How fast the player wants to move
    private float speed = 12f;

    //Standard value for gravity to be used in suvat and jumping equations
    [SerializeField] private float gravity = -19.62f;

    //The value for how high the player wants to jump
    private float jumpheight = 3.0f;

    //Makes a vectory3 called velocity to allow the change of the players velocity in both the jumping calculations and the gravity calculations
    private Vector3 velocity;

    //This transform(position) is placed at the bottom of the player mesh and is used to check wether the player is touching the ground or not
    [SerializeField] private Transform groundcheck;

    //Distance the player is from the ground when touching it
    private float groundDistance = 0.4f;

    //this layermask allows the player and the ground to be on the same layer to make sure that the code works if the player is touching a ground object
    [SerializeField] private LayerMask groundMask;

    //Either true or false on wether the player is touching the ground based on certain parameters
    private bool isgrounded;
    // Start is called before the first frame update
    void Start()
    {
        paused = gridshotNeat.paused;
    }

    // Update is called once per frame
    void Update()
    {
        //creates a tiny sphere at the bottom of the player and checks if anything is colliding with the ground mask and changes the bool "isgrounded" accordingly
        isgrounded = Physics.CheckSphere(groundcheck.position, groundDistance, groundMask);
            
        //Assigns a value to x and z based on the vertical and horizontal inputs from the player to be used in the movement code
        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        //if the player is grounded AND the player has no Y velocity, the y velocity of the player is removed. this is to make sure that the gravity pull is not being increased
        //while the player is grounded so that when the player is grounded for a long time, the y velocity resets to make sure that gravity acts normal on the next fall
        if(isgrounded && velocity.y < 0)
		{
            velocity.y = -2f;
		}

        //takes the directions that the player is facing and multiplies it by it by the value taken from the player input and places it into a vector3(x,y,z)
        Vector3 move = transform.right * x + transform.forward * z;

        //When the left shift button is pressed, it multiplies the movespeed by 2 to allow the player to sprint
		if (Input.GetKeyDown(KeyCode.LeftShift))
		{
            speed = (speed * 2);
		}

        //When the shift button is released, the movespeed is divided by 2 to stop the player from sprinting when the shift button is not pressed
        if (Input.GetKeyUp(KeyCode.LeftShift))
        {
            speed = (speed / 2);
        }

        //Uses the Move function with the move vector3 and mutliplies it by the player speed and time to allow the player to move
        controller.Move(move * speed * Time.deltaTime);


        //uses the physics equation v = sqrt(h * -2 * g) to calculate the amount of velocity needed to jump a certain height
        if(Input.GetKeyDown(KeyCode.Space) && isgrounded)
		{
            velocity.y = Mathf.Sqrt(jumpheight * -2f * gravity);
		}

        //Uses the suvat equation DeltaY = (1/2 * g) * sqr(t) to calculate the change in the y velocity of the player due to the gravitational pull
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }
}
