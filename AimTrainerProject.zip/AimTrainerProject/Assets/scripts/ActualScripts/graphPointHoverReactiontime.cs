using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
public class graphPointHoverReactionTime : MonoBehaviour
{
	private Color defaultColor;
	private void Start()
	{
		defaultColor = gameObject.GetComponent<Renderer>().material.color;


	}

	
	private void OnMouseExit()
	{
		//When no longer hovering over the object, it changes the colour back to the default colour
		gameObject.GetComponent<Renderer>().material.color = defaultColor;

	}


	private void OnMouseOver()
	{
		//when hovering over the object, it changes the colour to green
		gameObject.GetComponent<Renderer>().material.color = Color.green;
	}

	
}
