using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class P2_Options : MonoBehaviour
{
	//Variables
	private bool paused;
	//Variables

	//GameObjects
	[SerializeField] private GameObject optionsMenu;
	[SerializeField] private GameObject mainSettings;
	[SerializeField] private GameObject controlsMenu;
	[SerializeField] private GameObject audioMenu;
	[SerializeField] private GameObject crosshairMenu;
	//GameObjects

	//Buttons
    [SerializeField] private Button controlsButton, audioButton, crosshairButton;
	//[SerializeField] private Button audioButton;
	//[SerializeField] private Button crosshairButton;

	[SerializeField] private Button controlsToMainButton;
	[SerializeField] private Button audioToMainButton;
	[SerializeField] private Button crosshairToMainButton;
	//Buttons

	private void Update()
	{
		controlsButton.onClick.AddListener(delegate { goToControlsFromMain(); });
		audioButton.onClick.AddListener(delegate { goToAudioFromMain(); });
		crosshairButton.onClick.AddListener(delegate { goToCrosshairFromMain(); });

		controlsToMainButton.onClick.AddListener(delegate {goToMainFromControls(); });
		audioToMainButton.onClick.AddListener(delegate { goToMainFromAudio(); });
		crosshairToMainButton.onClick.AddListener(delegate {goToMainFromCrosshair(); });

		if (Input.GetKeyDown(KeyCode.Escape))
		{
			paused = !paused;
			controlsMenu.SetActive(false);
			audioMenu.SetActive(false);
			crosshairMenu.SetActive(false);
			mainSettings.SetActive(true);
		}

		if (paused)
		{
			optionsMenu.SetActive(true);
		}
		if (!paused)
		{
			optionsMenu.SetActive(false);
		}

	}

	//SUB SETTINGS TO MAIN METHODS
	private void goToMainFromControls()
	{
		controlsMenu.SetActive(false);
		mainSettings.SetActive(true);
	}
	private void goToMainFromAudio()
	{
		audioMenu.SetActive(false);
		mainSettings.SetActive(true);
	}
	private void goToMainFromCrosshair()
	{
		crosshairMenu.SetActive(false);
		mainSettings.SetActive(true);
	}
	//SUB SETTINGS TO MAIN METHODS






	




	//MAIN TO SUB SETTINGS METHODS
	private void goToControlsFromMain()
	{
		mainSettings.SetActive(false);
		controlsMenu.SetActive(true);
	}

	private void goToAudioFromMain()
	{
		mainSettings.SetActive(false);
		audioMenu.SetActive(true);
	}

	private void goToCrosshairFromMain()
	{
		mainSettings.SetActive(false);
		crosshairMenu.SetActive(true);
	}
	//MAIN TO SUB SETTINGS METHODS




	private void Start()
	{
		mainSettings.SetActive(false);
	}
}
