using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetScript : MonoBehaviour
{
	private float health = 10f;
	private float spawnedTime;
	private float totalReactionTime;
	private bool paused;
	private bool taskEnded;
	private GameObject gun;


	private void Start()
	{
		gun = GameObject.Find("1911");
	}

	private void Update()
	{
		paused = gun.GetComponent<gridshotNeat>().get_paused();
		taskEnded = gun.GetComponent<gridshotNeat>().get_taskEnded();



		if (!paused && !taskEnded)
		{
			//totalReactionTime = gridshotNeat.totalReactionTime;
			spawnedTime += Time.deltaTime;
		}
	}

	public void takedamage(float amount)
	{	
		health -= amount;
		if(health <= 0)
		{	
			Die();
		}

		void Die()
		{
			Debug.Log(spawnedTime);
			Destroy(gameObject);
		}

		
	}

	
	public float get_spawnedTime()
	{
		return spawnedTime;
	}
	
}
