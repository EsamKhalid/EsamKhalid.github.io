using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SetValueActive : MonoBehaviour
{
    [SerializeField] private GameObject pointDisplayValue;
    [SerializeField] private Camera graphCamera;
    private bool hittingPoint;

    void Update()
    {   
        RaycastHit hit;
        //Shoots out a raycast from the mouse position from the graph camera
        Ray ray = graphCamera.ScreenPointToRay(Input.mousePosition);
        //Sets hitting point to false by default
        hittingPoint = false;
        //returns true if the raycast is hitting an object and the object has the "graphPointHover" script
        //The only objects that contain that script are the graph points generated in the script "Gridhsot.cs"
        if (Physics.Raycast(ray, out hit) && (hit.transform.GetComponent<graphPointHoverAccuracy>() || hit.transform.GetComponent<graphPointHoverLinePath>()))
        {   
            hittingPoint = true;
            //Sets the display value object to true so it displays the point values next to the mouse
            pointDisplayValue.SetActive(true);

        }
		else
		{   //Sets the display valye ob
            pointDisplayValue.SetActive(false);
		}
    }
}
