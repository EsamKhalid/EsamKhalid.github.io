using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mainmenu : MonoBehaviour
{
	public void playRandshot()
	{
		SceneManager.LoadScene(sceneBuildIndex: 1);
	}
	public void playMassclick()
	{
		SceneManager.LoadScene(sceneBuildIndex: 2);
	}

	public void quitgame()
	{
		Debug.Log("quit");
		Application.Quit();
	}

}
