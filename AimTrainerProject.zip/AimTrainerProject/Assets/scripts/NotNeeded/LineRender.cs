using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LineRender : MonoBehaviour
{
    private List<Vector3> Lpos = new List<Vector3>();

    [SerializeField] private LineRenderer LR;

    private int targetcount;
    private int pos;


    // Start is called before the first frame update
    void Start()
    {   
        if(SceneManager.GetActiveScene().buildIndex == 1)
		{
            //targetcount = GameObject.Find("spawncube").GetComponent<targetspawner_randshot>().TargetCount;
        }

        LR.positionCount = targetcount;
        
    }
    // Update is called once per frame
    void Update()
    {

        if(SceneManager.GetActiveScene().buildIndex == 1)
		{
            if (Lpos.Count == targetcount)
            {
                pos = 0;
                while (pos < Lpos.Count)
                {
                    LR.SetPosition(pos, Lpos[pos]);
                    pos += 1;
                }

            }
        }
        
    }
}
