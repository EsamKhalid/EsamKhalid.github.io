using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class OptionsMenu : MonoBehaviour
{
	public float sens;
	private string temp;
	public float FOV;

	private void Start()
	{
		FOV = 60;
		sens = 100;
	}
	public void ChangeSenseSlider(float value)
	{
		sens = value;
	}

	public void ChangeSensInput(string s)
	{
		temp = s;
		if(int.Parse(temp) < 10)
		{
			sens = 10;
		}
		else if(int.Parse(temp) > 1000)
		{
			sens = 1000;
		}
		else
		{
			sens = int.Parse(temp);
		}
	}

	public void ChangeFOVSlider(float value)
	{
		FOV = value;
	}

	private void Update()
	{
		Debug.Log(sens);
	}
}
