using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test1 : MonoBehaviour
{

    private GameObject one;
    class spawner
	{
        private int randx;
        private int randy;
        private int randz;
        private int maxx;
        private int maxy;
        private int maxz;
        private Vector3 spawnpos;


		
        public void spawntargets()
		{
            randx = Random.Range(0, maxx);
            randy = Random.Range(0, maxy);
            randz = Random.Range(0, maxz);
            spawnpos.x = randx;
            spawnpos.y = randy;
            spawnpos.z = randz;
            return;
		}

        
        
	}

	private void Update()
	{
        spawner spawn = new spawner();
        
        
	}

}
