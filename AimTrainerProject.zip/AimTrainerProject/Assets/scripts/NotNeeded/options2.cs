using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class options2 : MonoBehaviour
{
	private float sens;
	private string temp;

	// Start is called before the first frame update
	void Start()
    {
        
    }

	public void ChangeSenseSlider(float value)
	{
		sens = value;
		Debug.Log(sens);
	}
	// Update is called once per frame
	void Update()
    {
        
    }
}
