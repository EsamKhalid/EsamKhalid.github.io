using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TargetAtive : MonoBehaviour
{
    public GameObject sphere;
    public GameObject sphere1;
    public GameObject sphere2;
    public GameObject sphere3;
    public GameObject sphere4;
    public GameObject sphere5;
    public GameObject sphere6;
    public GameObject sphere7;
    public GameObject sphere8;
    private bool activity = false;

    void Start()
    {   if (activity == false)
		{
            sphere.SetActive(false);
            sphere1.SetActive(false);
            sphere2.SetActive(false);
            sphere3.SetActive(false);
            sphere4.SetActive(false);
            sphere5.SetActive(false);
            sphere6.SetActive(false);
            sphere7.SetActive(false);
            sphere8.SetActive(false);   
        }
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
