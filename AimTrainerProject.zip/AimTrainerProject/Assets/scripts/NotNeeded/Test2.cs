using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test2 : MonoBehaviour
{
    private int y;
    
    public void sety(int value)
	{
        y = value;
	}
    void Start()
    {
       
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(GameObject.Find("Test1g").GetComponent<Test1>().health);
    }
}