using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bruh : MonoBehaviour
{
   
    // Start is called before the first frame update
    void Start()
    {
        GameObject target = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        target.transform.position = new Vector3(10, 20, 50);
        target.transform.localScale = new Vector3(2f, 2f, 2f);
        target.GetComponent<Renderer>().material.color = Color.green;

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
