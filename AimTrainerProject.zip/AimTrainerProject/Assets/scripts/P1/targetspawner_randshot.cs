using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class targetspawner_randshot : MonoBehaviour //dan was here!!!
{

    [SerializeField] private GameObject cornerCube1;
    [SerializeField] private GameObject cornerCube2;
    [SerializeField] private GameObject cornerCube3;
    [SerializeField] private GameObject cornerCube4;

    [SerializeField] private GameObject Target;
    [SerializeField] private GameObject tspawn;
    [SerializeField] private LineRenderer LR;

    private GameObject[] Lpos;
  
    private int TotalTargets = 0;
    private int TargetCount = 3;

    private int pos;

    private float randy;
    private float randx;
    private float randz;

    private float minx;
    private float maxx;
    private float miny;
    private float maxy;
    private float minz;
    private float maxz;


    private Vector3 spawnpos;
    private Vector3 center;

    void Start()
    {
        maxy = cornerCube1.transform.position.y;
        miny = cornerCube2.transform.position.y;
        minx = cornerCube2.transform.position.x;
        maxx = cornerCube3.transform.position.x;

        Application.targetFrameRate = 100;
  
        LR.positionCount = TargetCount;
    }
    void Update()
    {
        
        Lpos = GameObject.FindGameObjectsWithTag("target");
        TotalTargets = Lpos.Length;


        if(Lpos.Length == TargetCount)
		{
            pos = 0;
            while(pos < Lpos.Length)
			{
                LR.SetPosition(pos, Lpos[pos].transform.position);
                pos += 1;
			}
		}

        while (TotalTargets < TargetCount)
        {
            randy = Random.Range(miny, maxy);
            randx = Random.Range(minx, maxx);

            spawnpos = new Vector3(randx, randy, cornerCube1.transform.position.z);

            GameObject clone;
            clone = Instantiate(Target, spawnpos, tspawn.transform.rotation);
            clone.tag = "target";

            TotalTargets += 1;
        }

    }
}
