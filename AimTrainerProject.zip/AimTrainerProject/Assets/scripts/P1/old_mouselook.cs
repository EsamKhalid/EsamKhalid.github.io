using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class old_mouselook : MonoBehaviour
{
    //Taken from brackeys tutorial on fps character controller https://www.youtube.com/watch?v=_QajrabyTJc
    //Vlaue for how fast the player wants the look sensetivity
    private float sens = 125f;
    private float tempSense;
    private float tempFOV;
    private float tempADS;
    private float ADSmultiplier = 0.75f;
    private bool paused;

    //Options vars
    [SerializeField] private TMP_InputField sensInputField;
    [SerializeField] private TMP_InputField fovInputField;
    [SerializeField] private TMP_InputField adsInputField;
    [SerializeField] private GameObject optionsMenu;
    //End Options vars

    //Transform of the physical player body to rotate the player body along the Y axis to make sure that the player is always moving in the direction they are facing
    [SerializeField] private Transform playerbody;

    //Value of xrotation to allow the camera to rotate along the X axis to look up and down
    private float xrotation = 0f;

    private float CamFOV = 60f;

    void Start()
    {   //Code runs at the very start to lock the cursor in the middle of the screen
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = true;
        optionsMenu.SetActive(false);
        sensInputField.text = sens.ToString();
        fovInputField.text = CamFOV.ToString();
        adsInputField.text = ADSmultiplier.ToString();
    }

    public void ChangeSenseSlider(float value)
    {
        sensInputField.text = value.ToString();
        sens = value;
    }

    public void ChangeFOVSlider(float value)
	{
        fovInputField.text = value.ToString();
        CamFOV = value;
	}
    public void ChangeADSValue(float value)
	{
        adsInputField.text = (Mathf.Round(value * 100) / 100).ToString();
        ADSmultiplier = value;
	}
    public void OnSensInput()
    {  
        //checks if the input contains numbers or characters, if true then it changes the sens to the value
        if (float.TryParse(sensInputField.text, out tempSense) == true)
        {   
            //makes sure the entered value is in range of the sensitivity
            if (tempSense >= 10 && tempSense <= 500)
            {
                sens = tempSense;
            }
            //if false then it promps the player to enter a numerical value between the min and max
            else
            {
                Debug.Log("please enter a value between 10 and 500");
            }
        }
        //if false then it promps the player to enter a numerical value
        else
        {
            Debug.Log("please enter a number value");
            
        }
    }
    public void OnADSInput()
    {
        //checks if the input contains numbers or characters, if true then it changes the sens to the value
        if (float.TryParse(adsInputField.text, out tempADS) == true)
        {
            //makes sure the entered value is in range of the ads
            if (tempADS >= 0.01f && tempADS <= 1)
            {
                ADSmultiplier = tempADS;
            }
            //if false then it promps the player to enter a numerical value between the min and max
            else
            {
                Debug.Log("please enter a value between 0 and 1");
            }
        }
        //if false then it promps the player to enter a numerical value
        else
        {
            Debug.Log("please enter a number value"); 
        }
    }
    public void OnFOVInput()
    {
        //checks if the input contains numbers or characters, if true then it changes the sens to the value
        if (float.TryParse(fovInputField.text, out tempFOV) == true)
        {
            //makes sure the entered value is in range of the fov
            if (tempFOV >= 60 && tempFOV <= 110)
            {
                CamFOV = tempFOV;
            }
            //if false then it promps the player to enter a numerical value between the min and max
            else
            {
                Debug.Log("please enter a value between 60 and 110");
            }
        }
        //if false then it promps the player to enter a numerical value
        else
        {
            Debug.Log("please enter a number value");
        }
    }
    // Update is called once per frame
    void Update()
    {
        if (!paused)
		{
            //Gets the X input and multiplies it by the sens for the speed and Time.deltaTime to make the camera movement frame independant
            float mouseX = Input.GetAxis("Mouse X") * sens * Time.deltaTime;
            //Gets the X input and multiplies it by the sens for the speed and Time.deltaTime to make the camera movement frame independant
            float mouseY = Input.GetAxis("Mouse Y") * sens * Time.deltaTime;

            //Takes x rotation from mouseY because if it was equal, the rotation of the camera would be flipped compared to the Y input since it is rotating around the X axis
            xrotation -= mouseY;

            //Clamps the rotation of the camera around the X axis to make sure that the player cant look too far behind or too far down
            xrotation = Mathf.Clamp(xrotation, -90f, 90f);


            //Rotates the camera using quaternion and euler angles around the X axis to allow the camera to look up and down
            transform.localRotation = Quaternion.Euler(xrotation, 0f, 0f);

            //Applies a rotation transformation on the up vector(y vector) of the playerbody to rotate it around the y axis to look left and right
            playerbody.Rotate(Vector3.up * mouseX);
        }


        if (Input.GetMouseButtonDown(1))
		{
            CamFOV *= 0.75f;
            sens *= ADSmultiplier;
		}

        if (Input.GetMouseButtonUp(1)) // rohannn:)
        {
            CamFOV /= 0.75f;
            sens /= ADSmultiplier;
        }

		if (Input.GetKeyDown(KeyCode.Escape))
		{
            paused = !paused;
            optionsMenu.SetActive(false);
        }

		if (!paused)
		{   //While not paused
            optionsMenu.SetActive(false);
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
		}
		else
		{   //While Paused
            optionsMenu.SetActive(true);
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
		}
	
        //changes the main camera's FOV
        Camera.main.fieldOfView = CamFOV;
    }
}
