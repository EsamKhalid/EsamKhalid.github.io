using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Shooting : MonoBehaviour
{
    private float damage = 10f;
    private float range = 100f;

    [SerializeField] private Camera camera;
    [SerializeField] private GameObject gun;

    private Vector3 shotPosition;
    private float errorSize;

    private int shotsTotal;
    private int targetsHit;

    private float accuracy;

    [SerializeField] private AudioSource gunshot;

    [SerializeField] private LayerMask Player;

	// Update is called once per frame
	void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            shoot();
            shotsTotal += 1;
        }
    }
    void shoot()
    {
        RaycastHit hit;
        if (Physics.Raycast(camera.transform.position, camera.transform.forward, out hit, range, ~Player))
        {
            //Outputs the name of the target that has been hit

            //Debug.Log(hit.transform.name);
            //Checks the GameObject that has been hit to see if it has a "Target" Script on it
            old_targetScript target = hit.transform.GetComponent<old_targetScript>();
      
            //If the GameObject does have a target script on it, cause the target to take damage
            if (target != null)
            {
                target.takedamage(damage);
                
                //errorsize
                shotPosition = hit.point;
                errorSize += shotPosition.x - hit.transform.position.x;
                errorSize += shotPosition.y - hit.transform.position.y;
                targetsHit += 1;

                //accuracy completed
                accuracy = (targetsHit / shotsTotal) * 100;
            }
        }

    }
}