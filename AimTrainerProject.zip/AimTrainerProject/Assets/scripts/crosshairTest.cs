using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class crosshairTest : MonoBehaviour
{
    [SerializeField] private float sizex;
    [SerializeField] private float sizey;
    // Start is called before the first frame update
    void Start()
    {
        sizex = 10f;
        sizey = 31.37f;
    }

    // Update is called once per frame
    void Update()
    {
        gameObject.transform.GetComponent<RectTransform>().sizeDelta = new Vector2(sizex, sizey);
    }
}
