using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class polygonTest : MonoBehaviour
{
    [SerializeField] private GameObject cube1;



    [SerializeField] private GameObject[] objArr;

    [SerializeField] private float radius;
    [SerializeField] private int numSides;



    // Start is called before the first frame update
    void Start()
    {
        objArr = new GameObject[numSides];


        generatePolygon(radius, numSides);

    }
    // Update is called once per frame
    void Update()
    {
        
    }




    private void generatePolygon(float radius, int numSides)
	{
        float angleStep = 360 / numSides;
        for(int i = 0;i < numSides; i++)
		{
            objArr[i] = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            objArr[i].transform.position = cube1.transform.position + new Vector3(radius, 0, 0);
            objArr[i].transform.RotateAround(cube1.transform.position,Vector3.up, angleStep * i);
		}
	}





    









    private void createFromCircumCircle(float radius, float N)
	{
        float Rc = radius;
        float Ri = (Rc * (Mathf.Cos(Mathf.PI / N)));
        float edgeLength = 2 * Ri * Mathf.Sin(Mathf.PI / N);
        Debug.Log(Ri + "ri");
        Debug.Log(edgeLength + "EL");
	}
}
