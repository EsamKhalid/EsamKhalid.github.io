using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public  class MapGenerator : MonoBehaviour
{
    [SerializeField] private int mapWidth;
    [SerializeField] private int mapHeight;
    [SerializeField] private float noiseScale;

    public bool autoUpdate;
    public void generateMap() {
        float[,] noiseMap = NoiseGenerator.generateNoiseMap(mapWidth, mapHeight, noiseScale);

        MapDisplay display = FindObjectOfType<MapDisplay>();
        display.drawNoiseMap(noiseMap);
    }
}
