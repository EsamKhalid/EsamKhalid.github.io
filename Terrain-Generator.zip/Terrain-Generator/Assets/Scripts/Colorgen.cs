using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Colorgen : MonoBehaviour
{
    [SerializeField] private Material material;

    private Texture2D texture;

    void Start()
    {
        material.color = Color.black;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnApplicationQuit()
    {
        material.color = Color.white;
    }
}
