document.addEventListener("DOMContentLoaded",function(){
    function validateForm() {
        var firstName = document.getElementById('first-name').value;
        var description = document.getElementById('description').value;
        var email = document.getElementById('email').value;
        var confirmEmail = document.getElementById('confirm-email').value;
        var phone = document.getElementById('phone').value;
        var contactMethod = document.getElementById('contact-method').value;
        var date = document.getElementById('date').value;
    
        //Checking if all the fields are filled in
        if(firstName.trim() == "" || description.trim == "" || email.trim() == "" || confirmEmail.trim() == "" || phone.trim() == "" || contactMethod.trim() == "" || date.trim() == ""){
            window.alert("please fill in all fields");
            return false;
        }
        
        if(!checkEmails(email,confirmEmail)){
            return false;
        }
    
        if(!checkDate(date)){
            return false;
        }
    
        var firstName = document.getElementById('first-name').value;
            var description = document.getElementById('description').value;
            var email = document.getElementById('email').value;
            var phone = document.getElementById('phone').value;
            var contactMethod = document.getElementById('contact-method').value;
            var date = document.getElementById('date').value;
    
            var summary = 'Name: ' + firstName + '\n'
                    + 'Description: ' + description + '\n'
                    + 'Email: ' + email + '\n'
                    + 'Phone: ' + phone + '\n'
                    + 'Preferred Contact Method: ' + contactMethod + '\n'
                    + 'Date of Project: ' + date;
    
            window.alert(summary + "/n/n A confirmation email will be sent to " + email);
    
            document.getElementById("contact-form")
    }
      
     function checkEmails(email1, email2){
        if(email1 == email2){
            return true;
        }
        else{
            window.alert("confirm email does not match email")
            return false;
        }
    }
    
      
      // Function to check if the selected date is at least 1 day in the future
      function checkDate(date){
        var currentDate = new Date();
        var selectedDate = new Date(date);
    
        if(selectedDate.getDate() > currentDate.getDate()){
            return true;
        }
        else{
            window.alert("please enter a day that is at least 1 day ahead of today")
        }
    }
    
    
      document.getElementById('contact-form').addEventListener('submit', function(event) {
        event.preventDefault();
      
        if (validateForm()) {
          var firstName = document.getElementById('first-name').value;
          var description = document.getElementById('description').value;
          var email = document.getElementById('email').value;
          var phone = document.getElementById('phone').value;
          var contactMethod = document.getElementById('contact-method').value;
          var date = document.getElementById('date').value;
      
          var summary = 'Name: ' + firstName + '\n'
                      + 'Description: ' + description + '\n'
                      + 'Email: ' + email + '\n'
                      + 'Phone: ' + phone + '\n'
                      + 'Preferred Contact Method: ' + contactMethod + '\n'
                      + 'Date of Project: ' + date;
      
          alert(summary + '\n\nA confirmation email will be sent to ' + email);
      
          document.getElementById('contact-form').reset();
        }
      });
});
